# -*- coding: utf-8 -*-
"""
Created on Sun Oct 26 16:12:49 2025

@author: Ben Carlson

Program to simulate the noise PSD of an interferometric detector.
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import firwin2, lfilter, welch
import tkinter as tk
from tkinter import filedialog

def plot_PSD(xvals, yvals, title_str):
    ''' Plots the probability density function on a loglog plot.
    PARAMETERS
        xvals (ndarray): The array of frequency values to plot.
        yvals (ndarray): The array of values to plot vs frequency.
        title_str (str): Title to print on the graph.
    '''
    plt.figure(figsize=(10, 6))
    plt.loglog(xvals, yvals)
    plt.title(title_str)
    plt.xlabel(' log Frequency (Hz)')
    plt.ylabel('log PSD')
    plt.grid(True)
    plt.show()
    return

def statgaussnoisegen(nSamples, freqVec, sqrt_psdVec, fltrOrdr, sampFreq):
    ''' Generates a realization of stationary Gaussian noise from a given 
        2-sided PSD.
    PARAMETERS:
        nSamples (int): Number of samples for the generated noise.
        freqVec (ndarray): Array of frequency values.
        sqrt_psdVec (ndarray): Array of sqrt(PSD) values.
        fltrOrdr (int): Order of the FIR filter.
        sampFreq (float): Sampling frequency.
    RETURNS:
        outNoise (ndarray): Generated colored stationary Gaussian noise
    '''
    # Design FIR filter using firwin2 (equivalent to fir2 in MATLAB)
    b = firwin2(fltrOrdr+1, freqVec/(sampFreq/2), sqrt_psdVec)
    # Generate white Gaussian noise
    inNoise = np.random.randn(nSamples)
    # Pass the white noise through the filter to generate colored noise
    outNoise = lfilter(b, 1, inNoise)
    # Scale the output noise (equivalent to sqrt(sampFreq)*fftfilt in MATLAB)
    outNoise *= np.sqrt(sampFreq)
    return outNoise

def main():
    ''' Program to simulate the noise PSD of an interferometric detector. '''
    
    # Import the data
    try:
        # freqs, sq_S = np.loadtxt('C:/Users/tkz334/Desktop/Fall_2025/StatMethods/programs/iLIGOsensitivity.txt', unpack=True)  
        freqs, sq_S = np.loadtxt('testData.txt', unpack=True)
    except FileNotFoundError:
        # Open file explorer to select a file
        print('Could not find iLIGOsensitivity.txt')
        print('Please select it in the file explorer.')
        root = tk.Tk()
        filepath = filedialog.askopenfilename(title="Select the Data File", 
                    filetypes=(("Text files", "*.txt"), ("All files", "*.*")))
        if filepath == "":
            print("No file selected. Exiting program.")
            root.withdraw()
            root.quit()
            return
        print('File selected.')
        # Load data from selected file
        freqs, sq_S = np.loadtxt(filepath, unpack=True)   
        root.withdraw()
        root.quit()    

    # Plot the initial PSD before modifications
    plot_PSD(freqs, sq_S, 'Initial PSD Before Modifications')
    
    # Modify the data
    # Interpolate to find y(50), y(700)
    sq_S_50 = np.interp(50, freqs, sq_S)
    sq_S_700 = np.interp(700, freqs, sq_S)
    # Apply the clipping conditions
    sq_S[freqs <= 50] = sq_S_50
    sq_S[freqs >= 700] = sq_S_700
    # Add f = 0 if missing
    if freqs[0] != 0.0:
        freqs = np.insert(freqs, 0, 0.0)
        sq_S = np.insert(sq_S, 0, sq_S_50)
    # Plot the PSD after modifications
    plot_PSD(freqs, sq_S, 'PSD After Modifications')
    
    # Sampling Parameters for the noise realization
    nSamples = 20000 # number of samples to generate
    sampFreq = 2.0 * freqs[-1] # Nyquist frequency
    fltrOrdr = 500 # Set FIR filter order
    # Generate the noise realization using the statgaussnoisegen function
    outNoise = statgaussnoisegen(nSamples, freqs, sq_S, fltrOrdr, sampFreq)
    # Estimate the PSD of the LIGO noise
    freqs, psd = welch(outNoise, sampFreq, nperseg=256)
    # Plot the estimated PSD of the generated noise
    plot_PSD(freqs, psd, f'Estimated PSD')

if __name__ == "__main__":
    main()
