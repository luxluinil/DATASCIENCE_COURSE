# -*- coding: utf-8 -*-
"""
Created on Sun Oct 26 05:32:19 2025

@author: Ben Carlson

Program to enhance the signal in a given data set by estimating the noise PSD
and applying a whitening filter.
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import firwin2, lfilter, welch, spectrogram
import tkinter as tk
from tkinter import filedialog

def plot_PSD(xvals, yvals, title_str):
    ''' Plots the probability density function.
    PARAMETERS
        xvals (ndarray): The array of frequency values to plot.
        yvals (ndarray): The array of values to plot vs frequency.
        title_str (str): Title to print on the graph.
    '''
    plt.figure(figsize=(10, 6))
    plt.plot(xvals, yvals)
    plt.title(title_str)
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('PSD')
    plt.grid(True)
    plt.show()
    return

def plot_sig(t_vec, f_t, title_str):
    ''' Plots signal vs time and displays the title string.
    PARAMETERS
        t_vec (ndarray): The array of sampled times.
        f_t (ndarray): The array of function values at t_vec times.
        title_str (str): Title to print on the graph.
    '''
    plt.figure(figsize=(10, 6))
    plt.plot(t_vec, f_t, marker='.', markersize=12, linestyle='-')
    plt.xlabel('Time (sec)')
    plt.title(title_str)
    plt.grid(True)
    plt.show()
    return

def gen_spectro(signal, samp_interv, title_str):
    ''' Generates the spectrogram of a given signal and plots it.
    PARAMETERS
        signal (ndarray): The array of signal values.
        samp_interv (float): The step size between samples.
        title_str (str): Title to print on the graph.
    '''
    # Spectrogram parameters
    winLenSmpls = int(0.2 / samp_interv) # sec / interval
    ovrlpSmpls = int(0.1 / samp_interv) # sec / interval
    # Compute spectrogram
    f, t, Sxx = spectrogram(signal, fs=1.0/samp_interv, nperseg=winLenSmpls, 
                            noverlap=ovrlpSmpls)
    # Plot the Spectrogram
    plt.figure(figsize=(10, 6))
    plt.xlabel('Time (sec)')
    plt.ylabel('Frequency (Hz)')
    plt.pcolormesh(t, f, np.abs(Sxx), shading='auto')
    plt.title(title_str)
    plt.colorbar(label='Magnitude')
    plt.show()
    return

def main():
    '''Program to enhance the signal in a given data set by estimating the noise PSD
    and applying a whitening filter.'''
    
    # Import the data
    try:
        # test_data = np.loadtxt('C:/Users/tkz334/Desktop/Fall_2025/StatMethods/programs/testData.txt')  
        test_data = np.loadtxt('testData.txt')
    except FileNotFoundError:
        # Open file explorer to select a file
        print('Could not find testData.txt')
        print('Please select it in the file explorer.')
        root = tk.Tk()
        filepath = filedialog.askopenfilename(title="Select the Data File", 
                    filetypes=(("Text files", "*.txt"), ("All files", "*.*")))
        if filepath == "":
            print("No file selected. Exiting program.")
            root.withdraw()
            root.quit()
            return
        print('File selected.')
        # Load data from selected file
        test_data = np.loadtxt(filepath)   
        root.withdraw()
        root.quit()
    
    # Get the sampling Interval from the data. Time starts at 0.0, so use
        # second time value.
    samp_interv = test_data[1][0]
    sampFreq = 1 / samp_interv
    
    # Separate the first 5 seconds of noise.
    initial_noise = test_data[test_data[:,0] < 5]
    # Estimate the PSD of the initial noise
    freqVec, psdVec = welch(initial_noise[:,1], sampFreq, nperseg=256)
    # Plot the estimated PSD of the initial noise.
    plot_PSD(freqVec, psdVec, 'Estimated PSD of the Initial Noise')
    
    # Design FIR filter using firwin2 (equivalent to fir2 in MATLAB)
    fltrOrdr = 500
    b = firwin2(fltrOrdr+1, freqVec/(sampFreq/2), 1.0/np.sqrt(psdVec))
    # Pass the data through the whitening filter
    whitened_data = lfilter(b, 1, test_data[:,1])    

    # Plot data and spectrograms before and after whitening
    plot_sig(test_data[:,0], test_data[:,1], 'Data Before Whitening')
    plot_sig(test_data[:,0], whitened_data, 'Data After Whitening')
    gen_spectro(test_data[:,1], samp_interv, 'Data Before Whitening')
    gen_spectro(whitened_data, samp_interv, 'Data After Whitening')

if __name__ == "__main__":
    main()
