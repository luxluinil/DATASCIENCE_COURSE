# -*- coding: utf-8 -*-
"""
Created on Sat Oct 25 17:42:19 2025

@author: Ben Carlson

Code to generate trial values from a trivariate Normal distribution.
"""
import numpy as np
import matplotlib.pyplot as plt

def main():
    ''' FIXME: Docstring is incorrect. Generates a realization of White Gaussian Noise with 10,000 samples
    and various combinations of μ and σ.'''

    # Chosen parameters
    n_samples = 10000 # number of trial values to generate
    # Covariance Matrix
    C = np.array([[ 2.42324676,  1.7631107,   0.33233556],
                     [ 1.7631107,   2.94617225,  0.71693056],
                     [ 0.33233556,  0.71693056,  2.42029633]])
    
    # Get A matrix from C using two methods. Each create a different, valid
        # A matrix, but produce the same C matrix from A A.T. Cholesky is 
        # more efficient for sampling because it creates a lower triangular
        # matrix and doesn't have potential instabilities from taking square
        # roots like the eigenvalue decomposition does.
    # Method 1:
    L, Q = np.linalg.eigh(C)
    A = Q @ np.sqrt(np.diag(L))
    print('A from eigenvalue decomposition:\n', A)
    print('\nC from eigenvalue decomposition:\n', np.dot(A, A.T))
    # Method 2:
    A = np.linalg.cholesky(C)
    print('\nA from cholesky:\n',A)
    print('\nC from cholesky:\n', np.dot(A, A.T))

    # Generate independent normal random variables X1, X2, X3
    np.random.seed(0) # seed for reproducibility
    X = np.random.randn(n_samples, 3)  # 3 columns for X1, X2, X3
    # Compute Y = A * X (linear combination)
    Y = X.dot(A.T)

    # Calculate the sample mean of Y_1
    print('\nThe mean of Y_i is 0 because the mean of X_j is 0.')
    mean_Y1 = np.mean(Y[:, 0])
    print(f'The sample mean of Y1 is {mean_Y1}')

    # Plotting the 3D scatter plot
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter(Y[:, 0], Y[:, 1], Y[:, 2], c='r', marker='o', s=1)
    ax.set_xlabel('Y1')
    ax.set_ylabel('Y2')
    ax.set_zlabel('Y3')
    plt.title('3D Plot of 10,000 Trials')
    plt.show()

if __name__ == "__main__":
    main()
    