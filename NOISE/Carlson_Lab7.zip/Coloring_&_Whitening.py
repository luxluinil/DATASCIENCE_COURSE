# -*- coding: utf-8 -*-
"""
Created on Sat Oct 25 19:43:56 2025

@author: Ben Carlson

Program to generate a noise realization from a target PSD, and estimate the PSD
from that noise realization.
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import firwin2, lfilter, welch

def plot_PSD(xvals, yvals, title_str):
    ''' Plots the probability density function.
    PARAMETERS
        xvals (ndarray): The array of frequency values to plot.
        yvals (ndarray): The array of values to plot vs frequency.
        title_str (str): Title to print on the graph.
    '''
    plt.figure(figsize=(10, 6))
    plt.plot(xvals, yvals)
    plt.title(title_str)
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('PSD')
    plt.grid(True)
    plt.show()
    return

def plot_noise(tvals, nvals, title_str):
    ''' Plots the noise vs time.
    PARAMETERS
        tvals (ndarray): The array of time values to plot.
        FIXME yvals (ndarray): The array of noise values to plot vs time.
        title_str (str): Title to print on the graph.
    '''
    plt.figure(figsize=(10, 6))
    plt.plot(tvals, nvals)
    plt.title(title_str)
    plt.xlabel('Time (s)')
    plt.ylabel('Amplitude')
    plt.grid(True)
    plt.show()
    return

def plot_histogram(vals, title_str):
    ''' Plots the histogram of a given set of values.
    PARAMETERS
        vals (ndarray): The array of values to plot.
        title_str (str): Title to print on the graph.
    '''
    plt.figure(figsize=(10, 6))
    plt.hist(vals, bins=50, color='skyblue', edgecolor='black')
    plt.title(title_str)
    plt.xlabel('Value')
    plt.ylabel('Frequency')
    plt.grid(True)
    plt.show()
    return

def statgaussnoisegen(nSamples, freqVec, psdVec, fltrOrdr, sampFreq):
    ''' Generates a realization of stationary Gaussian noise from a given 
        2-sided PSD.
    PARAMETERS:
        nSamples (int): Number of samples for the generated noise.
        freqVec (ndarray): Array of frequency values.
        psdVec (ndarray): Array of PSD values that correspond to freqVec.
        fltrOrdr (int): Order of the FIR filter.
        sampFreq (float): Sampling frequency.
    RETURNS:
        inNoise (ndarray): Generated white stationary Gaussian noise
        outNoise (ndarray): Generated colored stationary Gaussian noise
    '''
    # Design FIR filter using firwin2 (equivalent to fir2 in MATLAB)
    b = firwin2(fltrOrdr+1, freqVec/(sampFreq/2), np.sqrt(psdVec))
    # Generate white Gaussian noise
    inNoise = np.random.randn(nSamples)
    # Pass the white noise through the filter to generate colored noise
    outNoise = lfilter(b, 1, inNoise)
    # Scale the output noise (equivalent to sqrt(sampFreq)*fftfilt in MATLAB)
    outNoise *= np.sqrt(sampFreq)
    return inNoise, outNoise

def target_psd(f):
    ''' Target 2-sided PSD function:     S = (f-100)(300-f)  if f in [100, 300]
                                           = 0               otherwise
    PARAMETERS
        f (ndarray): The array of frequencies to generate values for.
    RETURNS
        (ndarray): The array of PSD values.
    '''
    return np.where((f >= 100) & (f <= 300), (f - 100) * (300 - f) / 10000, 0)

def main():
    ''' Program to generate a noise realization from a target PSD, and estimate
    the PSD from that noise realization. '''
    # Sampling Parameters
    sampFreq = 1024  # Hz # Sampling frequency for noise realization
    start_samples = 16384 # Number of samples to generate
    sample_multiples = [1, 2, 4] # How many multiples of start_samples to use
    
    # Generate the frequency vector for PSD
    freqVec = np.arange(0, 512.1, 0.1)
    psdVec = target_psd(freqVec)
    # Plot the target PSD
    plot_PSD(freqVec, psdVec, f'Target PSD')
    # Set FIR filter order
    fltrOrdr = 500
    
    # For each multiple of start_samples
    for m in sample_multiples:
        # Time samples
        nSamples = start_samples * m
        timeVec = np.arange(nSamples) / sampFreq
        
        # Generate the colored Gaussian noise
        inNoise, outNoise = statgaussnoisegen(nSamples, freqVec, psdVec, 
                                              fltrOrdr, sampFreq)
        # Estimate the PSD of the generated noise
        f, pxx = welch(outNoise, sampFreq, nperseg=256)
        
        # Plot the estimated PSD of the generated noise
        plot_PSD(f, pxx, f'Estimated PSD of Output Noise, nSamples={nSamples}')
        # Plot the noise realizations vs time
        plot_noise(timeVec, inNoise, f'White Noise Realization, nSamples={nSamples}')
        plot_noise(timeVec, outNoise, f'Colored Noise Realization, nSamples={nSamples}')
        # Plot the histogram of the noise realization
        plot_histogram(outNoise, f'Histogram of the Noise Realization, nSamples={nSamples}')

if __name__ == "__main__":
    main()
