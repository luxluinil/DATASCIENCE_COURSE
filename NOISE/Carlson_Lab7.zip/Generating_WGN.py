# -*- coding: utf-8 -*-
"""
Created on Sat Oct 25 17:23:36 2025

@author: Ben Carlson

Generates a realization of White Gaussian Noise with 10,000 samples
and various combinations of μ and σ.
"""
import numpy as np
from math import sqrt
import matplotlib.pyplot as plt

def plot_histogram(vals, title_str):
    ''' Plots the histogram of a given set of values.
    PARAMETERS
        vals -> array(float) The array of values to plot.
        title_str -> string To print on the graph.
    '''
    plt.figure(figsize=(10, 6))
    plt.hist(vals, bins=50, color='skyblue', edgecolor='black')
    plt.title(title_str)
    plt.xlabel('Value')
    plt.ylabel('Frequency')
    plt.grid(True)
    plt.show()
    return

def main():
    ''' Generates a realization of White Gaussian Noise with 10,000 samples
    and various combinations of μ and σ.'''
    # Mean and standard deviation parameters for each realization.
    μs = [0, 0, 0, 2]
    σs = [1, 2, sqrt(2), sqrt(2)]
    
    # for each realization, plot histogram and find mean and standard deviation
    for μ,σ in zip(μs, σs):
        rand_gen = np.random.default_rng(0) # set seed for reproducibility.
        vals = rand_gen.normal(μ, σ, 10000) # mean, st deviation, num values
        mean = np.mean(vals)
        stdev = np.std(vals, ddof=1) # need ddof=1 for unbiased
        plot_histogram(vals, f'PDF: μ={μ:.3f}, σ={σ:.3f}. Calculated: μ={mean:.3f}, σ={stdev:.3f}.')

if __name__ == "__main__":
    main()
