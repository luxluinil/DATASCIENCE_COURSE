# -*- coding: utf-8 -*-
"""
Created on Fri Nov 14 14:06:13 2025

@author: Ben Carlson

Program to calculate the GLRT values of 3 imported data realizations of a 
quadratic chirp signal with unknown amplitude. Then estimates the significance 
of these GLRT values by running M data realizations under the null hypothesis
and calculating the p-values.
"""
import numpy as np
from math import pi
from scipy.signal import firwin2, fftconvolve
import tkinter as tk
from tkinter import filedialog

def crcbgenqcsig(t_vec, snr, coefs):
    ''' Generate a quadratic chirp signal for a given sampling interval.
    PARAMETERS
        t_vec (ndarray): The array of time values.
        snr (float): Scaling factor for signal amplitude.
        coefs (iterable): [a1, a2, a3] coefficients for phase polynomial.
    RETURNS
        f_t (ndarray): The array of chirp signal values.
    '''
    # Generate the signal and normalize
    φ_t = coefs[0]*t_vec + coefs[1]*(t_vec**2) + coefs[2]*(t_vec**3)
    f_t = np.sin(2.0*pi*φ_t)
    f_t = snr * f_t / np.linalg.norm(f_t)
    return f_t

def normsig4psd(sigVec, sampFreq, psdVec, snr):
    '''Normalize a given signal to have a specified SNR in specified noise PSD.
    PARAMETERS
        sigVec (ndarray): The signal vector to be normalized.
        sampFreq (float): The sampling frequency fs
        psdVec (ndarray): The array of PSD values for positive DFT frequencies.
        snr (float): The target SNR for the signal.
    RETURNS
        normSigVec (ndarray): The normalized signal array.
    '''
    nSamples = len(sigVec)
    kNyq = (nSamples//2)+1
    if len(psdVec) != kNyq:
        raise ValueError('Length of PSD is not correct')
    # Norm of signal squared is inner product of signal with itself
    normSigSqrd = innerprodpsd(sigVec, sigVec, sampFreq, psdVec)
    # Normalization factor
    normFac = snr / np.sqrt(normSigSqrd)
    # Normalize signal to specified SNR
    normSigVec = normFac * sigVec
    return normSigVec

def innerprodpsd(x, y, samp_freq, psd_vals_pos):
    '''Calculates the inner product of vectors X and Y for the case of Gaussian
    stationary noise having a specified power spectral density.
    PARAMETERS
        x, y (ndarray): The arrays of signal/data/noise values.
        samp_freq (float): The sampling frequency of X and Y is Fs.
        psd_vals_pos (ndarray): The array of PSD values at positive frequencies 
                                    in the DFT of X and Y.
    RETURNS
        (ndarray): The real component of the inner product of x and y.
    '''
    n = len(x)
    if len(y) != n:
        raise ValueError("Vectors must be the same length.")
    k_nyq = n // 2 + 1
    if len(psd_vals_pos) != k_nyq:
        raise ValueError("PSD values must be specified at positive DFT frequencies.")
    fftx = np.fft.fft(x)
    ffty = np.fft.fft(y)
    # We take care of even or odd number of samples when replicating PSD values
        # for negative frequencies.
    neg_start = 1 - (n % 2)
    psd_full = np.concatenate([psd_vals_pos, psd_vals_pos[(k_nyq - neg_start):1:-1]])
    data_len = samp_freq * n
    inn_prod = (1 / data_len) * np.dot(fftx / psd_full, np.conjugate(ffty))
    return np.real(inn_prod)

def noise_psd(f):
    ''' Target 2-sided PSD function:  
                S = (f-100)(300-f)/10000 + 1  if f in [100, 300]
                  = 1                           otherwise
    PARAMETERS
        f (ndarray): The array of frequencies to generate values for.
    RETURNS
        (ndarray): The array of PSD values.
    '''
    return ((f>=100) & (f<=300)) * (f-100)*(300-f)/10000 + 1

def statgaussnoisegen(n_samples, freq_vec, psd_vec, fir_order, samp_freq):
    ''' Generates a realization of stationary Gaussian noise from a given 
        2-sided PSD.
    PARAMETERS:
        n_Samples (int): Number of samples for the generated noise.
        freq_vec (ndarray): Array of frequency values.
        psd_vec (ndarray): Array of PSD values.
        fir_order (int): Order of the FIR filter.
        samp_freq (float): Sampling frequency.
    RETURNS:
        out_noise (ndarray): Generated white stationary Gaussian noise
    '''
    # Design FIR filter with T(f)= square root of target PSD
    b = firwin2(fir_order + 1, freq_vec / (samp_freq/2), np.sqrt(psd_vec))
    # Generate a WGN realization and pass it through the designed filter.
    in_noise = np.random.randn(n_samples)
    # Apply FIR filter (MATLAB's fftfilt equivalent)
    out_noise = np.sqrt(samp_freq) * fftconvolve(in_noise, b, mode="same")
    return out_noise

def glrtqcsig(x, y, psd_vec, input_params, samp_freq):
    '''Calculates the GLRT for a quadratic chirp signal with unknown amplitude.
    PARAMETERS
        x (ndarray): The array of time samples.
        y (ndarray): The array of data values.
        psd_vec (ndarray): The array of PSD values for positive DFT frequencies.
        input_params (iterable): [a1, a2, a3] coefficients for phase 
                        polynomial used to create the chirp signal.
        samp_freq (float): The sampling frequency in Hertz.
    RETURNS
        llr (float): The GLRT for amlitude-estimate case.
    '''
    # Generate the unit norm template signal
    sigVec = crcbgenqcsig(x, 1, input_params)
    templateVec = normsig4psd(sigVec, samp_freq, psd_vec, 1)
    # Inner product with data
    llr = innerprodpsd(y, templateVec, samp_freq, psd_vec)
    # GLRT for unknown amplitude (amplitude-estimated case)
    llr = llr*llr
    return llr

def main():
    '''Program to calculate the GLRT values of 3 imported data realizations of 
    a quadratic chirp signal with unknown amplitude. Then estimates the
    significance of these GLRT values by running M data realizations under the 
    null hypothesis and calculating the p-values.
    '''
    # import the data realizations
    file_names = ['data1.txt', 'data2.txt', 'data3.txt']
    data_realizations = []
    for file in file_names:
        try:
            # path = 'C:/Users/tkz334/Desktop/Fall_2025/StatMethods/programs/'
            # realization = np.loadtxt(path + file)  
            realization = np.loadtxt(file)
            data_realizations.append(realization)
        except FileNotFoundError:  # Open file explorer to select a file
            # yes it is inelegant to select each file separately, but the 
                # alternative was much more complicated to implement.
            print('Could not find ' + file)
            print('Please select it in the file explorer.')
            root = tk.Tk()
            root.withdraw()
            root.attributes('-topmost', True)
            filepath = filedialog.askopenfilename(title="Select the Data File", 
                        filetypes=(("Text files", "*.txt"), ("All files", "*.*")))
            if filepath == "":
                print("No file selected. Exiting program.")
                root.withdraw()
                root.quit()
                return
            print('File selected.')
            # Load data from selected file
            realization = np.loadtxt(filepath)   
            data_realizations.append(realization)
            root.withdraw()
            root.quit()   
    
    # signal parameters
    a1, a2, a3 = 10, 3, 3   
    samp_freq = 1024 # Hz
    n_samples = len(data_realizations[0]) # assume all realizations same length
    time_vec = np.arange(n_samples) / samp_freq
    
    # Generate the PSD vector to be used in the normalization. Should be
        # generated for all positive DFT frequencies. 
    data_len = n_samples / samp_freq
    k_nyq = (n_samples // 2) + 1
    pos_freq = np.arange(k_nyq) / data_len
    psd_vec = noise_psd(pos_freq)
    
    # Calculate the GLRT values
    GLRT_vals = np.zeros(len(data_realizations))
    for i, realiz in enumerate(data_realizations):
        GLRT_vals[i] = glrtqcsig(time_vec, realiz, psd_vec, 
                                                     [a1, a2, a3], samp_freq)
    print('\nGLRT values from the imported data realizations:', GLRT_vals)    
    print('\ncalculating p-values...\n')
    
    # Generate M data realizations under H0 (data only noise)
    M = 20000
    GLRT_H0 = np.zeros(M)
    np.random.seed(0)
    for m in range(M):
        noise = statgaussnoisegen(n_samples, pos_freq, psd_vec, 100, samp_freq)
        GLRT_H0[m] = glrtqcsig(time_vec, noise, psd_vec, [a1, a2, a3], samp_freq)
    # Compute the p-values
    for j, val in enumerate(GLRT_vals):  # these are the 3 GLRT values from data
        p = np.sum(GLRT_H0 > val) / M
        print(f"p-value for realization {j+1}: {p}")
    
if __name__ == "__main__":
    main()
