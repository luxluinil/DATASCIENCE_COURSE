# -*- coding: utf-8 -*-
"""
Created on Sun Nov  9 21:23:02 2025

@author: Ben Carlson

Modification of SNRcalc.m to plot 1 data realization in the time domain, the
periodogram of the signal and data, and the spectrogram of the data.
"""
import numpy as np
from math import pi
import matplotlib.pyplot as plt
from scipy.signal import firwin2, fftconvolve, spectrogram

def plot_periodo(signal, noise, samp_interv, title_str):
    ''' Generates the fast fourier transform (fft) of a given signal and plots
    the fft vs frequency.
    PARAMETERS
        signal (ndarray): The array of signal values to transform.
        noise (ndarray): The array of noise values to transform.
        samp_interv (float): The step size used to choose the frequency values.
        title_str (str): Title to print on the graph.
    '''
    N_samples = len(signal)
    # DFT sample corresponding to Nyquist frequency
    kNyq = (N_samples // 2) + 1
    # Positive Fourier frequencies
    posFreq = np.arange(0, kNyq) * (1/(N_samples*samp_interv))
    # FFT of the signal and noise
    fftSig = np.fft.fft(signal)
    fftNoise = np.fft.fft(noise)
    # Discard negative frequencies
    fftSig = fftSig[:kNyq]
    fftNoise = fftNoise[:kNyq]
    # Plot the Periodogram
    plt.figure(figsize=(10, 6))
    plt.plot(posFreq, np.abs(fftNoise), linestyle='-', color='b', label='data')
    plt.plot(posFreq, np.abs(fftSig), linestyle='-', color='r', label='signal')
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('|FFT|')
    plt.legend()
    plt.title(title_str)
    plt.grid(True)
    plt.show()
    return

def plot_spectro(signal, samp_interv, title_str):
    ''' Generates the spectrogram of a given signal and plots it.
    PARAMETERS
        signal (ndarray): The array of signal values.
        samp_interv (float): The step size between samples.
        title_str (str): Title to print on the graph.
    '''
    # Spectrogram parameters
    winLenSmpls = int(0.1 / samp_interv) # sec / interval
    ovrlpSmpls = int(0.09 / samp_interv) # sec / interval
    # Compute spectrogram
    f, t, Sxx = spectrogram(signal, fs=1.0/samp_interv, nperseg=winLenSmpls, 
                            noverlap=ovrlpSmpls)
    # Plot the Spectrogram
    plt.figure(figsize=(10, 6))
    plt.xlabel('Time (sec)')
    plt.ylabel('Frequency (Hz)')
    plt.pcolormesh(t, f, np.abs(Sxx), shading='auto')
    plt.title(title_str)
    plt.colorbar(label='Magnitude')
    plt.show()
    return

def gen_signal(t_vec, snr, coefs):
    ''' Generate a quadratic chirp signal multiplied by an exponential for a 
    given sampling interval.
    PARAMETERS
        t_vec (ndarray): The array of time values.
        snr (float): Scaling factor for signal amplitude.
        coefs (iterable): [a1, a2, a3] coefficients for phase polynomial.
    RETURNS
        f_t (ndarray): The array of signal values.
    '''
    # Generate the signal and normalize
    φ_t = coefs[0]*t_vec + coefs[1]*(t_vec**2) + coefs[2]*(t_vec**3)
    f_t = np.sin(2.0*pi*φ_t)
    f_t = snr * f_t / np.linalg.norm(f_t)
    f_t *= np.exp(t_vec)
    return f_t

def innerprodpsd(x, y, samp_freq, psd_vals_pos):
    '''Calculates the inner product of vectors X and Y for the case of Gaussian
    stationary noise having a specified power spectral density.
    PARAMETERS
        x, y (ndarray): The arrays of signal/data/noise values.
        samp_freq (float): The sampling frequency of X and Y is Fs.
        psd_vals_pos (ndarray): The array of PSD values at positive frequencies 
                                    in the DFT of X and Y.
    RETURNS
        (ndarray): The real component of the inner product of x and y.
    '''
    n = len(x)
    if len(y) != n:
        raise ValueError("Vectors must be the same length.")
    k_nyq = n // 2 + 1
    if len(psd_vals_pos) != k_nyq:
        raise ValueError("PSD values must be specified at positive DFT frequencies.")

    fftx = np.fft.fft(x)
    ffty = np.fft.fft(y)
    # We take care of even or odd number of samples when replicating PSD values
        # for negative frequencies.
    neg_start = 1 - (n % 2)
    psd_full = np.concatenate([psd_vals_pos, psd_vals_pos[(k_nyq - neg_start):1:-1]])

    data_len = samp_freq * n
    inn_prod = (1 / data_len) * np.dot(fftx / psd_full, np.conjugate(ffty))
    return np.real(inn_prod)

def statgaussnoisegen(n_samples, psd_matrix, fir_order, samp_freq):
    ''' Generates a realization of stationary Gaussian noise from a given 
        2-sided PSD.
    PARAMETERS:
        n_samples (int): Number of samples for the generated noise.
        psd_matrix (ndarray): Mx2 matrix containing frequencies and the 
                corresponding PSD values.
        fir_order (int): Order of the FIR filter.
        samp_freq (float): Sampling frequency.
    RETURNS:
        out_noise (ndarray): Generated stationary Gaussian noise
    '''
    freq_vec = psd_matrix[:,0]
    sqrt_psd = np.sqrt(psd_matrix[:,1])
    # Design FIR filter with T(f)= square root of target PSD
    b = firwin2(fir_order + 1, freq_vec / (samp_freq/2), sqrt_psd)
    # Generate a WGN realization and pass it through the designed filter.
    in_noise = np.random.randn(n_samples)
    # Apply FIR filter (MATLAB's fftfilt equivalent)
    out_noise = np.sqrt(samp_freq) * fftconvolve(in_noise, b, mode="same")
    return out_noise

def noise_psd(f):
    ''' Target 2-sided PSD function:  
                S = (f-100)(300-f)/10000 + 1  if f in [100, 300]
                  = 1                           otherwise
    PARAMETERS
        f (ndarray): The array of frequencies to generate values for.
    RETURNS
        (ndarray): The array of PSD values.
    '''
    return ((f>=100) & (f<=300)) * (f-100)*(300-f)/10000 + 1

def main():
    '''Modification of SNRcalc.m to plot 1 data realization in the time domain,
    the periodogram of the signal and data, and the spectrogram of the data. 
    '''
    # Target SNR
    snr = 10
    # Data generation parameters
    n_samples = 2048
    samp_freq = 1024
    time_vec = np.arange(n_samples) / samp_freq
    # Generate the signal that is to be normalized
    a1, a2, a3 = 10, 3, 3
    A = 1
    sig_vec = gen_signal(time_vec, A, [a1, a2, a3])

    # Generate the PSD vector to be used in the normalization. Should be
        # generated for all positive DFT frequencies. 
    data_len = n_samples / samp_freq
    k_nyq = (n_samples // 2) + 1
    pos_freq = np.arange(k_nyq) / data_len
    psd_pos = noise_psd(pos_freq)
    psd_matrix = np.column_stack([pos_freq, psd_pos])

    # Norm of signal squared is inner product of signal with itself
    norm_sig_sq = innerprodpsd(sig_vec, sig_vec, samp_freq, psd_pos)
    # Normalize signal to specified SNR
    sig_vec = snr * sig_vec / np.sqrt(norm_sig_sq)

    # LLR estimates
    n_trials = 1000
    llr_h0 = np.zeros(n_trials)
    llr_h1 = np.zeros(n_trials)
    np.random.seed(2)
    # Obtain LLR values for multiple noise realizations
    for k in range(n_trials):
        noise_vec = statgaussnoisegen(n_samples, psd_matrix, 100, samp_freq)
        llr_h0[k] = innerprodpsd(noise_vec, sig_vec, samp_freq, psd_pos)
    # Obtain LLR for multiple data (=signal+noise) realizations
    for k in range(n_trials):
        noise_vec = statgaussnoisegen(n_samples, psd_matrix, 100, samp_freq)
        data_vec = noise_vec + sig_vec # Add normalized signal
        llr_h1[k] = innerprodpsd(data_vec, sig_vec, samp_freq, psd_pos)

    # Signal to noise ratio estimate
    est_snr = (np.mean(llr_h1) - np.mean(llr_h0)) / np.std(llr_h0, ddof=1)
    print(f"Estimated SNR = {est_snr:.3f}")

    # Histogram
    plt.figure()
    plt.hist(llr_h0, bins=30, edgecolor='black', alpha=0.6, label="H0")
    plt.hist(llr_h1, bins=30, edgecolor='black', alpha=0.6, label="H1")
    plt.grid(True)
    plt.xlabel("LLR")
    plt.ylabel("Counts")
    plt.legend()
    plt.title(f"Estimated SNR = {est_snr:.3f}")
    plt.show()

    # Data realization
    plt.figure()
    plt.plot(time_vec, data_vec, label="data")
    plt.plot(time_vec, sig_vec, label="signal")
    plt.grid(True)
    plt.legend()
    plt.xlabel("Time (sec)")
    plt.ylabel("Data")
    plt.show()
    
    # Plot periodogram
    plot_periodo(sig_vec, data_vec, 1/samp_freq, 'Periodogram')
    
    # Plot spectrogram
    plot_spectro(data_vec, 1/samp_freq, 'Spectrogram')

if __name__ == "__main__":
    main()
