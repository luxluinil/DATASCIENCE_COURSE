# -*- coding: utf-8 -*-
"""
Created on Mon Nov 10 12:06:19 2025

@author: Ben Carlson
"""

"""
Calculate GLRT for Quadratic Chirp Signal
-----------------------------------------
Generalized Likelihood Ratio Test (GLRT) for a quadratic chirp when only
the amplitude is unknown.
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import spectrogram
from scipy.signal import firwin2, fftconvolve


def crcbgenqcsig(t_vec, snr, coefs):
    ''' Generate a quadratic chirp signal for a given sampling interval.
    PARAMETERS
        t_vec -> array(float) The array of time values.
        snr -> float Scaling factor for signal amplitude.
        coefs -> float[:] coefficients for phase polynomial.
    RETURNS
        f_t -> array(float) The array of chirp signal values.
    '''
    # Generate the signal and normalize
    φ_t = coefs[0]*t_vec + coefs[1]*(t_vec**2) + coefs[2]*(t_vec**3)
    f_t = np.sin(2.0*pi*φ_t)
    f_t = snr * f_t / np.linalg.norm(f_t)
    return f_t

def innerprodpsd(x, y, samp_freq, psd_vals_pos):
    '''Calculates the inner product of vectors X and Y for the case of Gaussian
    stationary noise having a specified power spectral density. Sn is a vector
    containing PSD values at the positive frequencies in the DFT of X and Y. 
    The sampling frequency of X and Y is Fs.
    '''
    n = len(x)
    if len(y) != n:
        raise ValueError("Vectors must be the same length.")
    k_nyq = n // 2 + 1
    if len(psd_vals_pos) != k_nyq:
        raise ValueError("PSD values must be specified at positive DFT frequencies.")

    fftx = np.fft.fft(x)
    ffty = np.fft.fft(y)
    # We take care of even or odd number of samples when replicating PSD values
        # for negative frequencies.
    neg_start = 1 - (n % 2)
    psd_full = np.concatenate([psd_vals_pos, psd_vals_pos[(k_nyq - neg_start):1:-1]])

    data_len = samp_freq * n
    inn_prod = (1 / data_len) * np.dot(fftx / psd_full, np.conjugate(ffty))
    return np.real(inn_prod)


def statgaussnoisegen(n_samples, psd_matrix, fir_order, samp_freq):
    '''Generates a realization Y of stationary gaussian noise with a target
    2-sided power spectral density given by PSD. Fs is the sampling frequency
    of Y. PSD is an M-by-2 matrix containing frequencies and the corresponding
    PSD values in the first and second columns respectively. The frequencies
    must start from 0 and end at Fs/2. The order of the FIR filter to be used
    is given by O.
    '''
    freq_vec = psd_matrix[:,0]
    sqrt_psd = np.sqrt(psd_matrix[:,1])
    # Design FIR filter with T(f)= square root of target PSD
    b = firwin2(fir_order + 1, freq_vec / (samp_freq/2), sqrt_psd)
    # Generate a WGN realization and pass it through the designed filter.
    in_noise = np.random.randn(n_samples)
    # Apply FIR filter (MATLAB's fftfilt equivalent)
    out = fftconvolve(in_noise, b, mode="same")
    return np.sqrt(samp_freq) * out

def normsig4psd(sigVec, sampFreq, psdVec, snr):
    nSamples = len(sigVec)
    kNyq = (nSamples//2)+1
    if len(psdVec) != kNyq:
        raise ValueError('Length of PSD is not correct')
    # Norm of signal squared is inner product of signal with itself
    normSigSqrd = innerprodpsd(sigVec,sigVec,sampFreq,psdVec)
    # Normalization factor
    normFac = snr/np.sqrt(normSigSqrd)
    # Normalize signal to specified SNR
    normSigVec = normFac*sigVec
    return normSigVec

def main():
    
    # -----------------------------------------------------------
    # Add paths (not needed in Python if functions are imported)
    # from signals import crcbgenqcsig
    # from noise import statgaussnoisegen, normsig4psd, innerprodpsd
    # -----------------------------------------------------------
    
    # Parameters for data realization
    nSamples = 2048
    sampFreq = 1024
    timeVec = np.arange(nSamples) / sampFreq
    
    # Supply PSD values
    def noisePSD(f):
        """Noise PSD definition."""
        return ((f >= 100) & (f <= 300)) * ((f - 100) * (300 - f) / 10000) + 1
    
    dataLen = nSamples / sampFreq
    kNyq = nSamples // 2 + 1
    posFreq = np.arange(kNyq) / dataLen
    psdPosFreq = noisePSD(posFreq)
    
    # Generate data realization
    a1, a2, a3 = 9.5, 2.8, 3.2
    A = 2  # SNR
    
    # Generate signal for data (arbitrary amplitude)
    sig4data = crcbgenqcsig(timeVec, 1, [a1, a2, a3])
    
    # Normalize signal to SNR = A for specified PSD
    sig4data = normsig4psd(sig4data, sampFreq, psdPosFreq, A)
    
    # Generate noise realization
    noiseVec = statgaussnoisegen(nSamples, np.column_stack((posFreq, psdPosFreq)), 100, sampFreq)
    
    # Data realization = noise + signal
    dataVec = noiseVec + sig4data
    
    # Plot time-domain signal
    plt.figure()
    plt.plot(timeVec, dataVec, label="Data")
    plt.plot(timeVec, sig4data, label="Signal")
    plt.xlabel("Time (sec)")
    plt.ylabel("Data")
    plt.title("Data realization for calculation of LR")
    plt.legend()
    plt.show()
    
    # Plot periodograms
    datFFT = np.abs(np.fft.fft(dataVec))
    sigFFT = np.abs(np.fft.fft(sig4data))
    
    plt.figure()
    plt.plot(posFreq, datFFT[:kNyq], label="Data")
    plt.plot(posFreq, sigFFT[:kNyq], label="Signal")
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("Periodogram of data")
    plt.legend()
    plt.show()
    
    # Spectrogram
    f, t, Sxx = spectrogram(dataVec, fs=sampFreq, nperseg=64, noverlap=60)
    plt.figure()
    plt.pcolormesh(t, f, np.abs(Sxx), shading="auto")
    plt.xlabel("Time (sec)")
    plt.ylabel("Frequency (Hz)")
    plt.title("Spectrogram of data")
    plt.show()
    
    # Compute GLRT
    # Generate the unit norm template signal
    sigVec = crcbgenqcsig(timeVec, 1, [a1, a2, a3])
    templateVec = normsig4psd(sigVec, sampFreq, psdPosFreq, 1)
    
    # Inner product with data
    llr = innerprodpsd(dataVec, templateVec, sampFreq, psdPosFreq)
    
    # GLRT for unknown amplitude (amplitude-estimated case)
    llr = llr**2
    print("GLRT value:", llr)
    
    # Estimate distribution under H0 (noise only) and H1 (signal+noise)
    nRlz = 500
    glrtH0 = np.zeros(nRlz)
    glrtH1 = np.zeros(nRlz)
    
    # For reproducibility
    np.random.seed(0)
    
    # Under H0
    for lpr in range(nRlz):
        noiseVec = statgaussnoisegen(nSamples, np.column_stack((posFreq, psdPosFreq)), 100, sampFreq)
        llr = innerprodpsd(noiseVec, templateVec, sampFreq, psdPosFreq)
        glrtH0[lpr] = llr**2
    
    # Under H1
    for lpr in range(nRlz):
        noiseVec = statgaussnoisegen(nSamples, np.column_stack((posFreq, psdPosFreq)), 100, sampFreq)
        dataVec = noiseVec + sig4data
        llr = innerprodpsd(dataVec, templateVec, sampFreq, psdPosFreq)
        glrtH1[lpr] = llr**2
    
    # Plot GLRT histograms
    plt.figure()
    plt.hist(glrtH0, bins=30, density=True, alpha=0.6, label="H0 (noise only)")
    plt.hist(glrtH1, bins=30, density=True, alpha=0.6, label="H1 (signal + noise)")
    plt.legend()
    plt.xlabel("GLRT")
    plt.ylabel("PDF")
    plt.title("Distribution of GLRT under H0 and H1")
    plt.show()

if __name__ == "__main__":
    main() 
