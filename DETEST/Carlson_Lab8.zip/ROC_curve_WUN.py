# -*- coding: utf-8 -*-
"""
Created on Sun Nov  9 04:02:16 2025

@author: Ben Carlson

Program to calculate and plot the Receiver Operating Characteristic (ROC) 
curves of various detection statistics with White Uniform Noise.
"""
import numpy as np
from numpy import random, zeros, array
import matplotlib.pyplot as plt

def plot_histogram(H0_vals, H1_vals, title_str):
    ''' Plots the histogram of a given set of values.
    PARAMETERS
        H0_vals, H1_vals (ndarray): The arrays of values to plot.
        title_str (str): Title to print on the graph.
    '''
    plt.figure(figsize=(10, 6))
    plt.hist(H0_vals, bins=40, density=True, alpha=0.5, edgecolor='black', label='H0')
    plt.hist(H1_vals, bins=40, density=True, alpha=0.5, edgecolor='black', label='H1')
    plt.title(title_str)
    plt.legend()
    plt.xlabel('Detection statistic value')
    plt.ylabel('PDF estimate')
    plt.grid(True)
    plt.show()
    return

def plot_ROC(Q_0, Q_ds, det_stat_names, title_str):
    ''' Plots the Receiver Operating Characteristic (ROC) curves for each 
    detection statistic.
    PARAMETERS
        Q_0 (ndarray): Array of false alarm probabilities.
        Q_ds (ndarray): Nested array of detection probabilities. One array of 
                        probabilities for each detection statistic.
        det_stat_names (dict_keys): An iterable of the names of each detection
                        statistic in the form of an ordered dynamic view.
        title_str (str): Title to print on the graph.
    '''
    plt.figure(figsize=(10, 6))
    for Q_d, name in zip(Q_ds, det_stat_names):
        plt.plot(Q_0, Q_d, label=name)
    plt.plot([0, 1], [0, 1], '--', color='k') # Plot diagonal line
    plt.xlabel('False Alarm Probability (Q0)')
    plt.ylabel('Detection Probability (Qd)')
    plt.legend(loc='lower right')
    plt.title(title_str)
    plt.grid(True)
    plt.show()
    return        

def main():
    ''' Program to calculate and plot the Receiver Operating Characteristic 
    (ROC) curves of various detection statistics with White Uniform Noise. '''
        
    N_samples = 100     # Number of samples per realization
    N_realz = 10000     # Number of realizations
    signal_vals = array([0.1, 0.03])     # DC signal values
    
    # Create Detection Statistic Functions and store their handles in dictionary.
    def gamma_1(x): # Sample Mean
        return np.mean(x)
    def gamma_2(x): # Sample Median
        return np.median(x)
    def gamma_3(x): # Center of Range
        return 0.5 * (np.min(x) + np.max(x))
    detection_statistics = { 'Sample Mean (LR for WGN)': gamma_1,
                             'Sample Median': gamma_2,
                             'Center of Range (LR for WUN)': gamma_3  }
    
    # Now get trial values of the detection statistic from data realizations 
        # under H0 and H1, and estimate their corresponding pdfs from these
        # trial values.
    # Initialize to store values
    gammaVals = zeros((len(signal_vals), 2*len(detection_statistics), N_realz))
    random.seed(0) # To allow reproducibility
    # Generate data realizations of white uniform noise from pdf U(-0.5, 0.5)
    for k in range(N_realz):
        noise_vec = random.uniform(-0.5, 0.5, N_samples)
        
        # Do calculations for each DC signal value.
        for s, signal_val in enumerate(signal_vals):
            
            y_vec = noise_vec + signal_val # Add the signal to the noise
            # Loop over detection statistics.  Calculate H1 and store H0.
            for j, det_stat in enumerate(detection_statistics.values()):
                gammaVals[s, 2*j,     k] = det_stat(noise_vec) # H0
                gammaVals[s, 2*j + 1, k] = det_stat(y_vec)     # H1
        
    # Plot estimated pdf for each detection statistic and signal under H0, H1
    for s, signal_val in enumerate(signal_vals):
        for j, det_stat_name in enumerate(detection_statistics.keys()):
            H0_vals = gammaVals[s, 2*j,     :]
            H1_vals = gammaVals[s, 2*j + 1, :]
            title_str = det_stat_name + f' Γ_{j+1}, signal = {signal_val}'
            plot_histogram(H0_vals, H1_vals, title_str)
    
    # False alarm probabilities, Q0 = (N - k) / N for an element H0_k
    Q_0 = (N_realz - np.arange(1, N_realz+1)) / N_realz
    # Detection probabilities, Qd = the fraction of H1 values exceeding H0_k
    Q_d = zeros((len(signal_vals), len(detection_statistics), N_realz))
    
    for s in range(len(signal_vals)):
        for j in range(len(detection_statistics)):
            H0 = np.sort(gammaVals[s, 2*j,     :])
            H1 = np.sort(gammaVals[s, 2*j + 1, :])

            # Compute detection probabilities
            for k in range(N_realz):
                # Count how many H1 values exceed the threshold h0Val[k]
                Q_d[s, j, k] = np.sum((np.sign(H1 - H0[k]) + 1) / 2) / N_realz
    
    # Plot the ROC curves for the detection statistics for each DC signal
    for s, signal_val in enumerate(signal_vals):
        title_str = f'ROC Curves for Different Detection Statistics, signal = {signal_val}'
        plot_ROC(Q_0, Q_d[s], detection_statistics.keys(), title_str)
    
if __name__ == "__main__":
    main()    
