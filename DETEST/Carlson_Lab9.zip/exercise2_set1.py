# -*- coding: utf-8 -*-
"""
Created on Mon Dec  1 13:47:58 2025

@author: Ben Carlson

Program to apply lbest PSO to a benchmark function (Generalized Rastrigin).
"""
from math import pi
from numpy import argmin, cos
from functools import partial

try: # Try to import custom file.
    from lbest_PSO import run_lbestPSO
except: # IDE cannot find custom file. Add path manually.
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    try:
        from lbest_PSO import run_lbestPSO
    except: # Still cannot find files.  Use must add path in IDE.
        print('\nYour IDE does not know where to find lbest_PSO.py')
        print('Please add this folder path to your IDE.')
        from sys import exit
        exit()

def Rastrigin(s_vals, p):
    ''' Calculates the value of the fitness value for the array s_vals using 
    the Rastrigin Function.
    PARAMETERS
        s_vals (ndarray): The array of standardized coordinate values.
        p (dictionary): Dictionary of parameters for the function.
    RETURNS
        f_val (float): The fitness value for this set of coordinates.
    '''
    # unpack params
    n = p["num dimensions"]
    xmin = p["low_bound"]
    xmax = p["high_bound"]
    # un-standardize the coordinates
    s_vals = s_vals*(xmax-xmin) + xmin 
    # Compute fitness
    f_val = 10.0 * n
    f_val += sum(s_vals*s_vals - 10.0*cos(2.0*pi*s_vals) )
    return f_val

def main():
    ''' 
    Program to apply lbest PSO to a benchmark function (Generalized Rastrigin).
    '''
    # Fitness function params and funtion handle
    N_runs = 2
    N_iter = 10000
    N_x = 20
    fitness_params = {"num dimensions": N_x,
                      "low_bound": -5.12,
                      "high_bound": 5.12 }
    fitness_handle = partial(Rastrigin, p=fitness_params)
    # Run lbest PSO
    fs, coords = run_lbestPSO(N_runs, N_iter, N_x, fitness_handle, seed=True)
    best_coords = coords[argmin(fs)]
    # unstandardize the coordinates
    xmin = fitness_params["low_bound"]
    xmax = fitness_params["high_bound"]
    best_coords = best_coords*(xmax-xmin) + xmin 
    print('\nUnstandardized best coordinate location: ', best_coords)

if __name__ == "__main__":
    main()
