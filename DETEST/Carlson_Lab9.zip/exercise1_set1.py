# -*- coding: utf-8 -*-
"""
Created on Sat Nov 22 23:11:16 2025

@author: Ben Carlson

Modify a signal generation function to receive a dictionary and compare the 
outputs.
"""
import numpy as np
from math import pi
from functools import partial
import matplotlib.pyplot as plt
from scipy.fft import fft

def gen_sig(t_vec, snr, coeffs):
    ''' Generate a quadratic chirp signal times an exponential for a given 
    sampling interval.
    PARAMETERS
        t_vec (ndarray): The array of time values.
        snr (float): Scaling factor for signal amplitude.
        coefs (iterable): [a1, a2, a3, a4] coefficients for phase polynomial.
    RETURNS
        f_t (ndarray): The array of chirp signal values.
    '''
    # Generate the signal and normalize
    φ_t = coeffs[0]*t_vec + coeffs[1]*(t_vec**2) + coeffs[2]*(t_vec**3)
    f_t = np.sin(2.0*pi*φ_t)
    f_t *= np.exp(coeffs[3]*t_vec)
    f_t = snr * f_t / np.linalg.norm(f_t)
    return f_t

def gen_sig_new(t_vec, snr, p):
    ''' Generate a quadratic chirp signal for a given sampling interval.
    PARAMETERS
        t_vec (ndarray): The array of time values.
        snr (float): Scaling factor for signal amplitude.
        p (dictionary): Dictionary of coefficients for phase polynomial.
    RETURNS
        f_t (ndarray): The array of chirp signal values.
    '''
    # Unpack the params
    a1 = p["phase_param1"]
    a2 = p["phase_param2"]
    a3 = p["phase_param3"]
    a4 = p["exp_param1"]
    # Generate the signal and normalize
    φ_t = a1*t_vec + a2*(t_vec**2) + a3*(t_vec**3)
    f_t = np.sin(2.0*pi*φ_t)
    f_t *= np.exp(a4*t_vec)
    f_t = snr * f_t / np.linalg.norm(f_t)
    return f_t

def plot_sig(t_vec, f_t, title_str):
    ''' Plots f_t vs t_vec and displays the title string.
    PARAMETERS
        t_vec -> array(float) The array of sampled times.
        f_t -> array(float) The array of function values at t_vec times.
        title_str -> string to print on the graph.
    '''
    plt.figure(figsize=(10, 6))
    plt.plot(t_vec, f_t, marker='.', markersize=12, linestyle='-')
    plt.xlabel('Time (sec)')
    plt.title(title_str)
    plt.grid(True)
    plt.show()
    return

def plot_periodo(signal, samp_interv, title_str):
    ''' Generates the fast fourier transform (fft) of a given signal and plots
    the fft vs frequency.
    PARAMETERS
        signal -> array(float) The array of signal values to transform.
        samp_interv -> float The step size used to choose the frequency values.
        title_str -> string To print on the graph.
    '''
    N_samples = len(signal)
    # DFT sample corresponding to Nyquist frequency
    kNyq = (N_samples // 2) + 1
    # Positive Fourier frequencies
    posFreq = np.arange(0, kNyq) * (1/(N_samples*samp_interv))
    # FFT of the signal
    fftSig = fft(signal)
    # Discard negative frequencies
    fftSig = fftSig[:kNyq]
    # Plot the Periodogram
    plt.figure(figsize=(10, 6))
    plt.plot(posFreq, np.abs(fftSig), marker='.', markersize=12, linestyle='-')
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('|FFT|')
    plt.title(title_str)
    plt.grid(True)
    plt.show()
    return

def main():
    ''' Modify a signal generation function to receive a dictionary and compare 
    the outputs.
    '''
    # Data generation parameters
    n_samples = 2048
    samp_freq = 1024
    time_vec = np.arange(n_samples) / samp_freq
    A = 1
    a1, a2, a3, a4 = 10.0, 3.0, 3.0, 2.5
    coeffs = np.array([a1, a2, a3, a4])
    params = {"phase_param1": a1,
              "phase_param2": a2,
              "phase_param3": a3,
              "exp_param1": a4}
    # There are multiple ways to implement function handles. partial is often
        # more efficient.
    # F = lambda x,y: gen_sig_new(x,y,params)
    sig_func = partial(gen_sig_new, p=params)
    
    # Generate signals from both the old and new functions.
    sig_vec_old = gen_sig(time_vec, A, coeffs)
    sig_vec_new = sig_func(time_vec, A)
    
    # Plot time series of each signal
    plot_sig(time_vec, sig_vec_old, 'old signal vs time')
    plot_sig(time_vec, sig_vec_new, 'new signal vs time')
    
    # Plot Periodogram of each signal
    plot_periodo(sig_vec_old, 1/samp_freq, 'old signal periodogram')
    plot_periodo(sig_vec_new, 1/samp_freq, 'new signal periodogram')

if __name__ == "__main__":
    main()
