# -*- coding: utf-8 -*-
"""
Created on Mon Dec  1 00:52:19 2025

@author: Ben Carlson

Program to plot a signal with SNR=10, 12, 15 using a function handle.
"""
import numpy as np
from math import pi
from functools import partial
import matplotlib.pyplot as plt
from scipy.fft import fft

def gen_sig_new(t_vec, snr, p):
    ''' Generate a quadratic chirp signal for a given sampling interval.
    PARAMETERS
        t_vec (ndarray): The array of time values.
        snr (float): Scaling factor for signal amplitude.
        p (dictionary): Dictionary of coefficients for phase polynomial.
    RETURNS
        f_t (ndarray): The array of chirp signal values.
    '''
    # Unpack the params
    a1 = p["phase_param1"]
    a2 = p["phase_param2"]
    a3 = p["phase_param3"]
    a4 = p["exp_param1"]
    # Generate the signal and normalize
    φ_t = a1*t_vec + a2*(t_vec**2) + a3*(t_vec**3)
    f_t = np.sin(2.0*pi*φ_t)
    f_t *= np.exp(a4*t_vec)
    f_t = snr * f_t / np.linalg.norm(f_t)
    return f_t

def plot_sig(t_vec, f_t, title_str):
    ''' Plots f_t vs t_vec and displays the title string.
    PARAMETERS
        t_vec -> array(float) The array of sampled times.
        f_t -> array(float) The array of function values at t_vec times.
        title_str -> string to print on the graph.
    '''
    plt.figure(figsize=(10, 6))
    plt.plot(t_vec, f_t, marker='.', markersize=12, linestyle='-')
    plt.xlabel('Time (sec)')
    plt.title(title_str)
    plt.grid(True)
    plt.show()
    return

def main():
    '''Program to plot a signal with SNR=10, 12, 15 using a function handle.'''
    # Data generation parameters
    snr_vals = np.array([10.0, 12.0, 15.0])
    params = {"phase_param1": 10.0,
              "phase_param2": 3.0,
              "phase_param3": 3.0,
              "exp_param1": 2.5 }
    n_samples = 2048
    samp_freq = 1024
    time_vec = np.arange(n_samples) / samp_freq
    # Create function handle
    sig_func = partial(gen_sig_new, time_vec, p=params)
    
    # Generate signals for all SNR values and plot.
    for SNR in snr_vals:
        sig_vec = sig_func(SNR)
        plot_sig(time_vec, sig_vec, f'signal vs time with SNR={SNR:.0f}')
    
if __name__ == "__main__":
    main()
