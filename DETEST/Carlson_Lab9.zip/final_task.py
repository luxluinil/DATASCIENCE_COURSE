# -*- coding: utf-8 -*-
"""
Created on Fri Nov 14 14:06:13 2025

@author: Ben Carlson

Program to generate a data realization for a quadratic chirp signal and run 
lbest PSO to find the signal parameters.
"""
import numpy as np
from scipy.signal import firwin2, fftconvolve
from functools import partial
import matplotlib.pyplot as plt

try: # Try to import custom files.
    from glrtqcsig4pso import glrtqcsig, crcbgenqcsig, innerprodpsd
    from lbest_PSO import run_lbestPSO
except: # IDE cannot find custom files. Add path manually.
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    try:
        from glrtqcsig4pso import glrtqcsig, crcbgenqcsig, innerprodpsd
        from lbest_PSO import run_lbestPSO
    except: # Still cannot find files.  Use must add path in IDE.
        print('\nYour IDE does not know where to find glrtqcsig4pso.py and lbest_PSO.py')
        print('Please add this folder path to your IDE.')
        from sys import exit
        exit()
    
def noise_psd(f):
    ''' Target 2-sided PSD function:  
                S = (f-50)(100-f)/625 + 1  if f in [50, 100]
                  = 1                           otherwise
    PARAMETERS
        f (ndarray): The array of frequencies to generate values for.
    RETURNS
        (ndarray): The array of PSD values.
    '''
    return ((f>=50) & (f<=100)) * (f-50)*(100-f)/625 + 1

def statgaussnoisegen(n_samples, freq_vec, psd_vec, fir_order, samp_freq):
    ''' Generates a realization of stationary Gaussian noise from a given 
        2-sided PSD.
    PARAMETERS:
        n_Samples (int): Number of samples for the generated noise.
        freq_vec (ndarray): Array of frequency values.
        psd_vec (ndarray): Array of PSD values.
        fir_order (int): Order of the FIR filter.
        samp_freq (float): Sampling frequency.
    RETURNS:
        out_noise (ndarray): Generated white stationary Gaussian noise
    '''
    # Design FIR filter with T(f)= square root of target PSD
    b = firwin2(fir_order+1, freq_vec / (samp_freq/2), np.sqrt(psd_vec))
    # Generate a WGN realization and pass it through the designed filter.
    in_noise = np.random.randn(n_samples)
    # Apply FIR filter (MATLAB's fftfilt equivalent)
    out_noise = np.sqrt(samp_freq) * fftconvolve(in_noise, b, mode="same")
    return out_noise

def fitness_func(time_vec, data_realiz, psd_vec, samp_freq, param_bounds, input_params):
    ''' A wrapper for glrtqcsig which receives standardized coordinates and 
    sends un-standardized coordinates to glrtqcsig. Serves as the fitness 
    function reference for PSO.
    PARAMETERS:
        time_vec (ndarray): The array of time samples.
        data_realiz (ndarray): The array of data values.
        psd_vec (ndarray): The array of PSD values for positive DFT frequencies.
        samp_freq (float): The sampling frequency in Hertz.
        param_bounds (ndarray): Array of boundary conditions for input_params.
        input_params (iterable): [a1, a2, a3] coefficients for phase po
    RETURNS:
        (float): The fitness function value for given input_params.
    '''
    # First, un-standardize the coordinates
    for i in range(0, len(input_params)):
        bc = param_bounds[i]
        input_params[i] = input_params[i]*(bc[1]-bc[0]) + bc[0]    
    # Compute fitness with GLRT
    return -glrtqcsig(time_vec, data_realiz, psd_vec, input_params, samp_freq)


def main():
    '''Program to generate a data realization for a quadratic chirp signal and 
    run lbest PSO to find the signal parameters. '''
    # create the data realization
    n_samples = 512
    samp_freq = 512 #Hz
    time_vec = np.arange(n_samples) / samp_freq
    np.random.seed(2)
    # signal parameters
    a1, a2, a3 = 10.0, 3.0, 3.0
    params = np.array([a1, a2, a3])
    snr = 10.0
    # generate the signal vector
    sig_vec = crcbgenqcsig(time_vec, snr, params)
    # Generate the PSD vector to be used in the normalization. Should be
        # generated for all positive DFT frequencies. 
    data_len = n_samples / samp_freq
    k_nyq = (n_samples // 2) + 1
    pos_freq = np.arange(k_nyq) / data_len
    psd_pos = noise_psd(pos_freq)
    norm_sig_sq = innerprodpsd(sig_vec, sig_vec, samp_freq, psd_pos)
    # Normalize signal to specified SNR
    sig_vec *= snr / np.sqrt(norm_sig_sq)
    # generate the noise
    noise_vec = statgaussnoisegen(n_samples, pos_freq, psd_pos, 100, samp_freq)
    # create realization
    data_realiz = noise_vec + sig_vec

    # Fitness function parameter ranges and funtion handle
    a1_min, a1_max = 1.0, 180.0
    a2_min, a2_max = 1.0, 10.0
    a3_min, a3_max = 1.0, 10.0
    param_bounds = np.array([[a1_min, a1_max], [a2_min, a2_max], [a3_min, a3_max]])
    fitness_handle = partial( fitness_func, 
                       time_vec, data_realiz, psd_pos, samp_freq, param_bounds)

    # Run lbest PSO
    N_runs = 8
    N_iter = 1000
    N_x = 3
    all_fs, all_best_loc = run_lbestPSO(N_runs, N_iter, N_x, fitness_handle)
    
    # Unstandardize the coordinates
    coords_standardized = all_best_loc[np.argmin(all_fs)]
    coords = np.zeros((len(coords_standardized)))
    for i, val in enumerate(coords_standardized):
        bc = param_bounds[i]
        coords[i] = val*(bc[1]-bc[0]) + bc[0]   
    print('\nFinal coordinates converted from standardized:', coords)
    # get estimated signal with the new parameters
    est_sig_vec = crcbgenqcsig(time_vec, snr, coords)
    norm_est_sig_sq = innerprodpsd(est_sig_vec, est_sig_vec, samp_freq, psd_pos)
    est_sig_vec *= snr / np.sqrt(norm_est_sig_sq)

    # Plot estimated and true signal together
    plt.figure()
    plt.plot(time_vec, data_realiz, label='data realization', color='skyblue')
    plt.plot(time_vec, sig_vec, label='true signal', color='r')
    plt.plot(time_vec, est_sig_vec, label='best estimated signal', color='g')
    plt.grid(True)
    plt.legend()
    plt.title('Plot of estimated and true signal together')
    plt.xlabel("time")
    plt.show()
    
    # Plot all PSO results together
    plt.figure()
    plt.plot(time_vec, data_realiz, label='data realization', color='skyblue')
    # plot each PSO result
    for j, loc in enumerate(all_best_loc):
        coords = np.zeros((len(loc)))
        # Unstandardize the coordinates
        for i, val in enumerate(loc):
            bc = param_bounds[i]
            coords[i] = val*(bc[1]-bc[0]) + bc[0]  
        est_sig = crcbgenqcsig(time_vec, snr, coords)
        norm_est_sig_sq = innerprodpsd(est_sig_vec, est_sig_vec, samp_freq, psd_pos)
        est_sig_vec *= snr / np.sqrt(norm_est_sig_sq)
        plt.plot(time_vec, est_sig_vec, label=f'estimated signal {j+1}')
    plt.grid(True)
    plt.legend()
    plt.title(f'Results from all {N_runs} PSO runs')
    plt.xlabel("time")
    plt.show()
    
if __name__ == "__main__":
    main()
