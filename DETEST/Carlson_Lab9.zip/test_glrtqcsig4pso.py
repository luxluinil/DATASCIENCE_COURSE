# -*- coding: utf-8 -*-
"""
Created on Fri Nov 14 14:06:13 2025

@author: Ben Carlson

Program to create a data realization with colored Gaussian noise and SNR=10 
quadratic chirp signal. Then compute the fitness with glrtqcsig for various
values of the chirp parameters and show that the fitness function is 
minimized at the true value.
"""
import numpy as np
from scipy.signal import firwin2, fftconvolve
import matplotlib.pyplot as plt
from functools import partial

try: # Try to import custom file.
    from glrtqcsig4pso import glrtqcsig, crcbgenqcsig, innerprodpsd
except: # IDE cannot find custom file. Add path manually.
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    try:
        from glrtqcsig4pso import glrtqcsig, crcbgenqcsig, innerprodpsd
    except: # Still cannot find file.  Use must add path in IDE.
        print('\nYour IDE does not know where to find glrtqcsig4pso.py')
        print('Please add this folder path to your IDE.')
        from sys import exit
        exit()

def noise_psd(f):
    ''' Target 2-sided PSD function:  
                S = (f-100)(300-f)/10000 + 1  if f in [100, 300]
                  = 1                           otherwise
    PARAMETERS
        f (ndarray): The array of frequencies to generate values for.
    RETURNS
        (ndarray): The array of PSD values.
    '''
    return ((f>=100) & (f<=300)) * (f-100)*(300-f)/10000 + 1

def statgaussnoisegen(n_samples, freq_vec, psd_vec, fir_order, samp_freq):
    ''' Generates a realization of stationary Gaussian noise from a given 
        2-sided PSD.
    PARAMETERS:
        n_Samples (int): Number of samples for the generated noise.
        freq_vec (ndarray): Array of frequency values.
        psd_vec (ndarray): Array of PSD values.
        fir_order (int): Order of the FIR filter.
        samp_freq (float): Sampling frequency.
    RETURNS:
        out_noise (ndarray): Generated white stationary Gaussian noise
    '''
    # Design FIR filter with T(f)= square root of target PSD
    b = firwin2(fir_order+1, freq_vec / (samp_freq/2), np.sqrt(psd_vec))
    # Generate a WGN realization and pass it through the designed filter.
    in_noise = np.random.randn(n_samples)
    # Apply FIR filter (MATLAB's fftfilt equivalent)
    out_noise = np.sqrt(samp_freq) * fftconvolve(in_noise, b, mode="same")
    return out_noise

def fitness_func(time_vec, data_realiz, psd_vec, samp_freq, param_bounds, input_params):
    ''' A wrapper for glrtqcsig which receives standardized coordinates and 
    sends un-standardized coordinates to glrtqcsig. Serves as the fitness 
    function reference for PSO.
    PARAMETERS:
        time_vec (ndarray): The array of time samples.
        data_realiz (ndarray): The array of data values.
        psd_vec (ndarray): The array of PSD values for positive DFT frequencies.
        samp_freq (float): The sampling frequency in Hertz.
        param_bounds (ndarray): Array of boundary conditions for input_params.
        input_params (iterable): [a1, a2, a3] coefficients for phase po
    RETURNS:
        (float): The fitness function value for given input_params.
    '''
    # First, un-standardize the coordinates
    for i in range(0, len(input_params)):
        bc = param_bounds[i]
        input_params[i] = input_params[i]*(bc[1]-bc[0]) + bc[0]    
    # Compute fitness with GLRT
    return -glrtqcsig(time_vec, data_realiz, psd_vec, input_params, samp_freq)

def main():
    '''Program to create a data realization with colored Gaussian noise and 
    SNR=10 quadratic chirp signal. Then compute the fitness with glrtqcsig for
    various values of the chirp parameters and show that the fitness function 
    is minimized at the true value. '''
    # create the data realization
    n_samples = 2048
    samp_freq = 1024
    time_vec = np.arange(n_samples) / samp_freq
    np.random.seed(2)
    # signal parameters
    a1, a2, a3 = 10.0, 3.0, 3.0
    params = np.array([a1, a2, a3])
    snr = 10.0
    # generate the signal vector
    sig_vec = crcbgenqcsig(time_vec, snr, params)
    # Generate the PSD vector to be used in the normalization. Should be
        # generated for all positive DFT frequencies. 
    data_len = n_samples / samp_freq
    k_nyq = (n_samples // 2) + 1
    pos_freq = np.arange(k_nyq) / data_len
    psd_pos = noise_psd(pos_freq)
    norm_sig_sq = innerprodpsd(sig_vec, sig_vec, samp_freq, psd_pos)
    # Normalize signal to specified SNR
    sig_vec *= snr / np.sqrt(norm_sig_sq)
    # generate the noise
    noise_vec = statgaussnoisegen(n_samples, pos_freq, psd_pos, 100, samp_freq)
    # create realization
    data_realiz = noise_vec + sig_vec

    # Parameter ranges
    a1_min, a1_max = 0.0, 20.0
    A = np.arange(a1_min, a1_max, 0.01)
    a2_min, a2_max = 0.0, 5.0
    a3_min, a3_max = 0.0, 5.0
    param_bounds = np.array([ [a1_min, a1_max], [a2_min, a2_max], [a3_min, a3_max] ])
    # Standardized coordinates
    x2 = (a2 - a2_min)/(a2_max - a2_min) 
    x3 = (a3 - a3_min)/(a3_max - a3_min) 
    fit_params = np.array([0.0, x2, x3])
    # Calculate fitness values for each row of X
    GLRT_vals = np.zeros((len(A)))
    fitness_handle = partial( fitness_func, 
                       time_vec, data_realiz, psd_pos, samp_freq, param_bounds)
    for i, A_val in enumerate(A):
        fit_params[0] = (A_val - a1_min)/(a1_max - a1_min)
        GLRT_vals[i] = fitness_handle(fit_params.copy())

    # Plot GLRT values against the values of A
    min_index = GLRT_vals.argmin() # Get min GLRT
    plt.figure()
    plt.plot(A, GLRT_vals)
    plt.scatter(A[min_index], GLRT_vals[min_index], color='r')
    plt.grid(True)
    plt.title("GLRT fitness vs A")
    plt.xlabel("A")
    plt.ylabel("GLRT")
    plt.show()
    
if __name__ == "__main__":
    main()
