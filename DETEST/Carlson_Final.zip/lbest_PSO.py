# -*- coding: utf-8 -*-
"""
Created on Tue Jul  1 20:48:51 2025

@author: Ben Carlson

Version of lbest_PSO_frame.py for lab9 of Statistical Methods Fall 2025.

Program to compute the global minimum via lbest Particle-Swarm Optimization.

update log:
    July 1, 2025:
        bjc - Made this routine callable from PSO_Launcher.py
    Nov 19, 2025:
        bjc - Modified initial summary printing.
    Dec 2, 2025:
        bjc - Fixed error when sending instance of coords instead of copy.
"""
from numpy import array, ndarray, zeros, float64, argmin, random, inf, hstack, vstack
from math import sqrt, pi, isclose
from collections import deque
from collections.abc import Iterable
import datetime
import time

def check_inputs(N_runs, N_iterations, N_coords, fitness_func, N_particles, 
                 N_local, use_vmax, seed, premade_Rs, eq_type, verbose):
    '''
    Function to check the user inputs so the program doesn't crash. Note that
        the fitness function is only tested to make sure it is a callable 
        function and the fitness function arguments are never tested to give
        the user flexibility with their custom fitness function.
    
    Parameters
    ----------
    N_runs : should be int > 0 (int-valued float allowed)
        The number of PSO runs the program will execute.
    N_iterations : should be int > 0 (int-valued float allowed)
        The number of iterations per run.
    N_coords : should be int > 0 (int-valued float allowed)
        The number of parameters that PSO will estimate.
    fitness_func : should be a callable function
        The fitness function that PSO will use to estimate parameters.
    N_particles : should be int > 0 (int-valued float allowed)
        The number of particles that will search the parameter space.
    N_local : should be int > 0 and <= N_particles (int-valued float allowed)
        The number of particles in each neighborhood. If N_local = N_particles,
            it is equivalent to gbest PSO.
    use_vmax : should be bool
        True if the v_max limit will be used in the search.
    seed : should be bool
        True if the random numbers should be repeatable.
    premade_Rs : should be an iterable of numbers between 0.0 and 1.0 inclusive
        A list of pre-made random numbers to use in the PSO algorithm.
    eq_type : should be string
        Determines the type of update equation to use in the method.
    verbose : should be bool
        True will cause info to be printed.

    Returns
    -------
    input_errors : bool
        True if there are errors in the given inputs.
    '''
    input_errors = False
    N_r_good = True
    N_i_good = True
    N_p_good = True
    N_c_good = True
    
    # Check N_runs
    if not isinstance(N_runs, (int, float)):
        print("\nInput Error: N_runs must have an integer value > 0.",
              " Received type ", type(N_runs))
        input_errors = True
        N_r_good = False
    elif  (N_runs < 1) or not isclose(N_runs%1.0, 0.0):
        print("\nInput Error: N_runs must have an integer value > 0.",
              " Received ", N_runs)
        input_errors = True
        N_r_good = False
        
    # Check N_iterations
    if not isinstance(N_iterations, (int, float)):
        print("\nInput Error: N_iterations must have an integer value > 0.",
              " Received type ", type(N_iterations))
        input_errors = True
        N_i_good = False
    elif (N_iterations < 1) or not isclose(N_iterations%1.0, 0.0):
        print("\nInput Error: N_iterations must have an integer value > 0.",
              " Received ", N_iterations)
        input_errors = True
        N_i_good = False
        
    # Check N_coords
    if not isinstance(N_coords, (int, float)):
        print("\nInput Error: N_coords must have an integer value > 0.",
              " Received type ", type(N_coords))
        input_errors = True
        N_c_good = False
    elif (N_coords < 1) or not isclose(N_coords%1.0, 0.0):
        print("\nInput Error: N_coords must have an integer value > 0.",
              " Received ", N_coords)
        input_errors = True
        N_c_good = False
        
    # Check fitness_func
    if not callable(fitness_func):
        print("\nInput Error: fitness_func must be a callable function.")
        input_errors = True
        
    # Check N_particles
    if not isinstance(N_particles, (int, float)):
        print("\nInput Error: N_particles must have an integer value > 0.",
              " Received type ", type(N_particles))
        input_errors = True
        N_p_good = False
    elif (N_particles < 1) or not isclose(N_particles%1.0, 0.0):
        print("\nInput Error: N_particles must have an integer value > 0.",
              " Received ", N_particles)
        input_errors = True
        N_p_good = False
        
    # Check N_local
    if not isinstance(N_local, (int, float)):
        print("\nInput Error: N_local must have an integer value > 0",
              "and <= N_particles. Received type ", type(N_local))
        input_errors = True
    elif (N_local < 1) or not isclose(N_local%1.0, 0.0) or (
                                        N_p_good and (N_local > N_particles)):
        print("\nInput Error: N_local must have an integer value > 0",
              "and <= N_particles. Received ", N_local)
        input_errors = True
            
    # Check use_vmax
    if not isinstance(use_vmax, bool):
        print('\nInput Error: use_vmax must be a boolean of value True or ',
              'False. Received type ', type(use_vmax))
        input_errors = True
        
    # Check seed
    if not isinstance(seed, bool):
        print('\nInput Error: seed must be a boolean of value True or ',
              'False. Received type ', type(seed))
        input_errors = True
        
    # Check premade_Rs
    if isinstance(premade_Rs, (str, bytes, dict)):
        print("\nInput Error: premade_Rs must be an iterable of numbers, not",
              "a string, bytes, or dict. Received type ", type(premade_Rs))
        input_errors = True
    elif(not isinstance(premade_Rs, Iterable)):
        print("\nInput Error: premade_Rs must be an iterable of numbers.",
              "Received type ", type(premade_Rs))
        input_errors = True
    else:
        premade_Rs = list(premade_Rs)
        N_Rs = len(premade_Rs)
        if (N_Rs > 0) and N_r_good and N_i_good and N_c_good and N_p_good:
            correct_length = 2*N_runs*(N_iterations+1)*N_coords*N_particles
            if not isclose(N_Rs, correct_length):
                print("\nInput Error: The number of premade random numbers",
                      "does not match the chosen",
                      "runs/iterations/coords/particles. length should be ", 
                      correct_length, " length received was ", N_Rs)
                input_errors = True
            else:
                for i,r in enumerate(premade_Rs):
                    if not isinstance(r,(int, float)) or not (0.0 <= r <= 1.0):
                        print("\nInput Error: premade_Rs must contain numbers",
                            "between 0.0 and 1.0 inclusive. Input check found",
                            "element at index = ", i, " with type=", type(r), 
                            " and value=", r)
                        input_errors = True
                        break

    # Check eq_type
    if not isinstance(eq_type, str):
        print('\nInput Error: eq_type must be a string. Received type ', type(eq_type))
        input_errors = True
    elif (eq_type != 'inertia') and (eq_type != 'constriction'):
        print('\nInput Error: eq_type must be \'inertia\' or \'constriction\'',
              'Received ', eq_type)        
        input_errors = True
        
    # Check verbose
    if not isinstance(verbose, bool):
        print('\nInput Error: verbose must be a boolean of value True or ',
              'False. Received type ', type(verbose))
        input_errors = True
    
    return input_errors

def update_particle(current_particle, pbest, lbest, w, N_x, func, random_nums, use_inertia):
    ''' Calculates the new position and velocity of 1 particle. Calculates the 
    value of the fitness function for the new coordinates, but returns infinity
    if the particle is outside the boundary conditions.
        parameters
            current_particle -> [[:],[:]] contains an array of coordinate 
                    values and an array of velocities.
            pbest -> [:] an array of coordinate values that produce the best 
                    fitness function result this particle has found so far.
            gbest -> [:] an array of coordinate values that produce the best
                    fitness function result found among all particles so far.
            w -> float64 The inertia factor, unique for each iteration.
        returns
            new_x -> [:] an array of updated coordinate values.
            new_v -> [:] an array of updated velocity values.
            inf or fitness_f(new_x) -> float64 this is the value of the fitness
                    function for the updated coordinates.
    '''
    (x_vals, v_vals) = current_particle
    new_x, new_v = zeros(N_x, dtype=float64), zeros(N_x, dtype=float64)
    
    #Constants
    v_max = 0.5
    C1 = 2.0
    C2 = 2.0
    # Constriction factor
    phi = C1 + C2
    K = 2.0 / abs(2.0 - phi - sqrt(phi*phi - 4.0*phi))
    
    if len(random_nums) > 0:
        # Get random R1 and R2 values from pre-set array.    
        R1 = [random_nums.popleft() for _ in range(N_x)]
        R2 = [random_nums.popleft() for _ in range(N_x)]
    else:        
        # Create random R1 and R2 values
        R1 = random.uniform(0.0, 1.0, N_x)
        R2 = random.uniform(0.0, 1.0, N_x)
    
    # If new position is outside boundary conditions, flag to return inf.
    outside_boundary = False
    
    # iterate over each coordinate.
    for i in range(0, N_x):
        # Get the previous coordinate and velocity values.
        prev_x, prev_v = x_vals[i], v_vals[i]
        
        if use_inertia:# Velocity update with inertia factor
            updated_v = (w*prev_v + R1[i]*C1*(pbest[i] - prev_x) 
                                                    + R2[i]*C2*(lbest[i] - prev_x))
        else: # Velocity update with constriction
            updated_v = K * (prev_v + R1[i]*C1*(pbest[i] - prev_x) 
                                                  + R2[i]*C2*(lbest[i] - prev_x))
        # Velocity clamping
        if abs(updated_v) > v_max:
            updated_v = v_max * updated_v / abs(updated_v)
        new_v[i] = updated_v
            
        # Position update
        updated_x  = prev_x + new_v[i] 
        if (updated_x < 0) or (updated_x > 1): # check boundary conditions.
            outside_boundary = True
        new_x[i] = updated_x
    
    # If the new location is outside the boundary, return fitness = infinity
    if outside_boundary:
        return new_x, new_v, inf
    return new_x, new_v, func(new_x.copy())


def run_iteration(current_particles, pbest_vals, lbest_vals, 
                  N_particles, iteration, N_iter,
                  N_x, func, random_nums, use_inertia):
    ''' Runs 1 iteration of the PSO method by calling update_particle for each
    particle.
        parameters
            current_particles -> [[[:],[:]],] an array of array pairs. Each 
                    pair corresponds to the coordinate array and velocity 
                    array of a particle.
            pbest_vals -> [[:],] a list of coordinate value arrays that produce
                    the best fitness function results found by each particle 
                    so far.
            iteration -> int64 The iteration, used in the inertia factor.
        returns
            new_f_vals -> [:] a list of the most recent batch of fitness
                    function results for each particle.
            new_particles -> [[:],[:],] a list of array pairs. Each pair 
                    corresponds to the updated coordinate array and velocity 
                    array of a particle.
    '''
    # Initialize lists for the new fitness function values, coordinates, 
    #   and velocities.  Calculate the intertia factor.
    new_f_vals, new_particles = [], []
    w = 0.9 - 0.5*(iteration-1)/(N_iter-1)
    
    # Run update_particle on each particle.
    for j in range(0, N_particles):
        new_x, new_v, new_f = update_particle(
            current_particles[j], pbest_vals[j], lbest_vals[j], w, N_x, 
            func, random_nums, use_inertia)
        new_f_vals.append( new_f )
        new_particles.append( [new_x, new_v] )
    return new_f_vals, new_particles


def perform_run(N_particles, N_l, N_iter, N_x, func, random_nums, use_inertia, verbose):
    ''' Runs all iterations of the PSO method for 1 run by calling 
    run_iteration N_iter times.
        parameters
        returns
            final_f -> float64 This is the best fitness function value found
                        by any particle during this run,
            gbest -> [:] An array containing the coordinate values that produce
                        final_f.
    '''
    v_max = 0.5
    # Create lists to store the coordinates, velocities of each particle, and 
    #   the best fitness function values obtained by each particle.
    particles = [ [[zeros(N_x, dtype=float64), zeros(N_x, dtype=float64)]] 
                     for i in range (N_particles)]
    best_f_vals = zeros(N_particles, dtype=float64)
    
    # Initialize the particle positions and velocities
    if len(random_nums) > 0: # premade set of random numbers
        # Fill the coordinates.
        for i in range(N_x):
            for j in range(N_particles):
                x = random_nums.popleft()
                particles[j][0][0][i] = x
        # Fill the velocities.
        for i in range(N_x):
            for j in range(N_particles):
                x = particles[j][0][0][i]
                v = random_nums.popleft()-x
                # Velocity clamping
                if v > v_max: 
                    particles[j][0][1][i] = v_max
                elif v < -v_max:
                    particles[j][0][1][i] = -v_max
                else:
                    particles[j][0][1][i] = v
        # Fill the initial fitness function values.
        for i in range(N_particles):
            best_f_vals[i] = array(func(particles[i][0][0].copy()))
            
    else: # generate new random numbers
        for i in range(N_particles):
            for j in range(N_x):
                # generate the random values in standardized coordinates
                x = random.uniform(0, 1)
                particles[i][0][0][j] = x
                v = random.uniform(0-x, 1-x) # standardized boundary conditions
                # Velocity clamping
                if v > v_max: 
                    particles[i][0][1][j] = v_max
                elif v < -v_max:
                    particles[i][0][1][j] = -v_max
                else:
                    particles[i][0][1][j] = v    
            best_f_vals[i] = array(func(particles[i][0][0].copy()))

    # Determine the particle best and local best at iteration 0.
    pbest_vals = array([ p[0][0] for p in particles])
    lbest_vals = array([  vstack((pbest_vals[i-1:], pbest_vals[:i-1]))[:N_l] [
        argmin( hstack((best_f_vals[i-1:], best_f_vals[:i-1]))[:N_l] )]  
        for i in range(0, N_particles)])
    # Print initial best position and function value for reference.
    if verbose:    
        gbest = pbest_vals[argmin(best_f_vals)]
        print('\ninitial function value = ', min(best_f_vals))
        print('initial coordinates = ', gbest)
    
    # Run N_iter iterations to update the coordinates and velocities.
    for iteration in range(1, N_iter+1):
        # Update the values.
        new_f_vals, new_particles = run_iteration( 
                    [p[-1] for p in particles], pbest_vals, lbest_vals, 
                    N_particles, iteration, N_iter, N_x, 
                    func, random_nums, use_inertia)
        # Compare fitness values and update pbest
        for f in range(0, N_particles):
            particles[f].append( new_particles[f] )
            if new_f_vals[f] < best_f_vals[f]:
                best_f_vals[f] = new_f_vals[f]
                pbest_vals[f] = new_particles[f][0]
        # Update lbest
        lbest_vals = array([ vstack((pbest_vals[i-1:],pbest_vals[:i-1]))[:N_l][
            argmin( hstack((best_f_vals[i-1:], best_f_vals[:i-1]))[:N_l] )]  
            for i in range(0, N_particles)])

    gbest = pbest_vals[ argmin( best_f_vals ) ]
    final_f = min(best_f_vals)
    # Print final best position and function value for reference.
    if verbose:
        print('\nfinal function value = ', final_f)
        print('final coordinates = ', gbest)
    
    return final_f, gbest


'''*************************************************************************'''
'''*************************************************************************'''
def run_lbestPSO(N_runs, N_iterations, N_coords, fitness_func, N_particles=40, N_local=3,
                 vmax=0.5, use_vmax=True, seed=False, premade_Rs=[], use_inertia=True, verbose=True):
    eq_type = 'inertia'
    
    st = time.time()
    # Check inputs
    input_errors = check_inputs(N_runs, N_iterations, N_coords, 
                     fitness_func, N_particles, N_local,
                     use_vmax, seed, premade_Rs, eq_type, verbose)
    if input_errors: # exit program if inputs are invalid
        exit()
    # All inputs are correct. Now modify and define for the program.
    if seed:
        random.seed(0)
    if isinstance(premade_Rs, ndarray):
        premade_Rs = premade_Rs.tolist()
    premade_Rs = deque(premade_Rs)   
    
    N_iter = N_iterations
    N_x = N_coords
        
    # Print summary of settings.
    if verbose:
        print('\tlbest_PSO began running on', datetime.datetime.now())
        print(N_runs, 'runs of ', N_iter, 'iterations.') 
        print(N_particles, 'particles with ', N_local, 'per neighborhood.')
        print(N_x, 'coordinates')
        print('seed = ', seed)
        if len(premade_Rs)>0:
            print('Random numbers provided by user.')
        else:
            print('Random numbers generated by program.')
        print('use_inertia = ', use_inertia)            # TODO
        print('verbose = ', verbose)
    
    

    all_fs, all_gbests = [], []
    # Run N_runs runs and store the final coordinates/fitness values for each.
    for i in range(0, N_runs):
        rst = time.time() 
        if verbose:
            print('\n\t\tRUN: ',i+1,'------------')
        
        run_f, run_gbest = perform_run(N_particles, N_local, N_iter, N_x, 
                                fitness_func, premade_Rs, use_inertia, verbose)
        all_fs.append( run_f )
        all_gbests.append( run_gbest )

        if verbose:        
            print('\ntime for run ',i+1,': %0.3f seconds'%(time.time()-rst))
    
    final_fitness_val = min(all_fs)
    final_coords = all_gbests[argmin(all_fs)]
    
    if verbose:
        print('\n\t\tFINAL RESULTS ----------')
        print('\nbest function value = ', final_fitness_val)
        print('best coordinates = ', final_coords)
        print('\ntotal time to run %0.3f seconds'%(time.time()-st))

    return all_fs, all_gbests
        


'''******************************MAIN***************************************'''
'''*************************************************************************'''
def main():  # Example Run
    # Number of PSO runs
    N_runs = 2
    # Number of iterations per run
    N_iter = 5000
    # coordinate boundary conditions
    boundary_conditions = array([[-10.0, 10.0], # bounds on x1
                                  [-10.0, 10.0], # bounds on x2
                                   [-10.0, 10.0],
                                   [-10.0, 10.0],
                                   [-10.0, 10.0],
                                   [-10.0, 10.0],
                                   [-10.0, 10.0],
                                   [-10.0, 10.0],
                                   [-10.0, 10.0],
                                [-10.0, 10.0]]) # etc
    # Number of coordinates
    N_x = len(boundary_conditions)
    from numpy import loadtxt
    random_nums = loadtxt('C:/Users/tkz334/Desktop/Mohanty/new_programs/Randoms_from_matlab.txt')

    from math import cos
    def fitness_f(s_vals, bcs=boundary_conditions):
        ''' Calculates the value of the fitness function for the array s_vals.
        This is currently set to use the Rastrigin Function.'''
        f_val = 0.0
        for i in range(0, N_x):
            # First, un-standardize the coordinates
            bc = bcs[i]
            x = s_vals[i]*(bc[1]-bc[0]) + bc[0]
            # Compute fitness
            f_val += x*x - 10.0*cos(2.0*pi*x)
        f_val += 10.0*N_x
        return f_val
    
    fs, coords = run_lbestPSO(N_runs, N_iter, N_x, 
             fitness_f, seed=True, premade_Rs=[])#random_nums)
    return

if __name__ == '__main__':
    main()  
