# -*- coding: utf-8 -*-
"""
Created on Sun Dec  7 01:23:22 2025

@author: Ben Carlson

Program to determine if a imported data series contains a quadratic chirp 
signal using PSO and GLRT and to estimate the parameters.
"""
import numpy as np
import scipy as sp
from scipy.signal import firwin2, fftconvolve, welch, spectrogram
from scipy.interpolate import interp1d
from functools import partial
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import filedialog
from sys import exit

try: # Try to import custom .py files.
    from glrtqcsig4pso import glrtqcsig
    from lbest_PSO import run_lbestPSO
except: # IDE cannot find custom files. Add path manually.
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    try:
        from glrtqcsig4pso import glrtqcsig
        from lbest_PSO import run_lbestPSO
    except: # Still cannot find files.  Use must add path in IDE.
        print('\nYour IDE does not know where to find the .py files.')
        print('Please add this folder path to your IDE.')
        exit()
    
def load_mats():
    ''' This function loads the .mat files and reads the information. It 
    implements checks to allow the user to coose the files if the IDE cannot
    find them and checks the keys to make sure the correct files were chosen.
    RETURNS
        samp_freq_data (float): The sampling frequency used in the data.
        samp_freq_train (float): The sampling frequency used in the training data.
        data_vec (ndarray): The array of data values.
        train_vec (ndarray): The array of training values (noise).
    '''
    # Load the data from the .mat files
    try:
        analysis_data_import = sp.io.loadmat('analysisData.mat')
        train_data_import = sp.io.loadmat('TrainingData.mat')
    except FileNotFoundError:
        # Open file explorer to select the files
        print('\nCould not find the .mat files')
        # select analysisData.mat
        print('Please select the analysisData.mat file in the file explorer.')
        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)
        filepath = filedialog.askopenfilename(title="Select analysisData.mat", 
                    filetypes=(("MAT files", "*.mat"), ("All files", "*.*")))
        if filepath == "":
            print("No file selected. Exiting program.")
            root.withdraw()
            root.quit()
            exit()
        print('analysisData.mat selected.')
        analysis_data_import = sp.io.loadmat(filepath)
        # select TrainData.mat
        print('\nPlease select the TrainData.mat file in the file explorer.')
        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)
        filepath = filedialog.askopenfilename(title="Select TrainData.mat", 
                    filetypes=(("MAT files", "*.mat"), ("All files", "*.*")))
        if filepath == "":
            print("No file selected. Exiting program.")
            root.withdraw()
            root.quit()
            exit()
        print('TrainData.mat selected.')
        train_data_import = sp.io.loadmat(filepath)
        # remove the window
        root.withdraw()
        root.quit()    

    # Unpack the data
    try: # use try in case the wrong files were selected or if they were switched.
        samp_freq_data = analysis_data_import['sampFreq'][0][0]
        samp_freq_train = train_data_import['sampFreq'][0][0]
        data_vec = analysis_data_import['dataVec'][0]
        train_vec = train_data_import['trainData'][0]
    except KeyError:
        print('\nThe .mat files were chosen incorrectly. They may have been switched. Please try again.')
        exit()
    return samp_freq_data, samp_freq_train, data_vec, train_vec
    
def plot_PSD(xvals, yvals, nxvals, nyvals, title_str, uselog=False):
    ''' Plots the probability density function on a standard or loglog plot.
    PARAMETERS
        xvals (ndarray): The array of frequency values to plot.
        yvals (ndarray): The array of values to plot vs frequency.
        title_str (str): Title to print on the graph.
        uselog (bool): True for using loglog plot.
    '''
    plt.figure(figsize=(10, 6))
    if uselog:
        plt.loglog(xvals, yvals, label='initial PSD')
        plt.loglog(nxvals, nyvals, label='modified PSD')
        plt.xlabel('log Frequency (Hz)')
        plt.ylabel('log PSD')
    else:
        plt.plot(xvals, yvals, label='initial PSD')
        plt.plot(nxvals, nyvals, label='modified PSD')
        plt.xlabel('Frequency (Hz)')
        plt.ylabel('PSD')
    plt.title(title_str)
    plt.legend()
    plt.grid(True)
    plt.show()
    return

def gen_spectro(signal, samp_interv, title_str):
    ''' Generates the spectrogram of a given signal and plots it.
    PARAMETERS
        signal (ndarray): The array of signal values.
        samp_interv (float): The step size between samples.
        title_str (str): Title to print on the graph.
    '''
    # Spectrogram parameters
    winLenSmpls = 64#int(0.2 / samp_interv) # sec / interval
    ovrlpSmpls = 60#int(0.1 / samp_interv) # sec / interval
    # Compute spectrogram
    f, t, Sxx = spectrogram(signal, fs=1.0/samp_interv, nperseg=winLenSmpls, 
                            noverlap=ovrlpSmpls)
    # Plot the Spectrogram
    plt.figure(figsize=(10, 6))
    plt.xlabel('Time (sec)')
    plt.ylabel('Frequency (Hz)')
    plt.pcolormesh(t, f, np.abs(Sxx), shading='auto')
    plt.title(title_str)
    plt.colorbar(label='Magnitude')
    plt.show()
    return
    
def statgaussnoisegen(n_samples, freq_vec, psd_vec, fir_order, samp_freq):
    ''' Generates a realization of stationary Gaussian noise from a given 
        2-sided PSD.
    PARAMETERS:
        n_Samples (int): Number of samples for the generated noise.
        freq_vec (ndarray): Array of frequency values.
        psd_vec (ndarray): Array of PSD values.
        fir_order (int): Order of the FIR filter.
        samp_freq (float): Sampling frequency.
    RETURNS:
        out_noise (ndarray): Generated white stationary Gaussian noise
    '''
    # Design FIR filter with T(f)= square root of target PSD
    b = firwin2(fir_order+1, freq_vec / (samp_freq/2), np.sqrt(psd_vec))
    # Generate a WGN realization and pass it through the designed filter.
    in_noise = np.random.randn(n_samples)
    # Apply FIR filter (MATLAB's fftfilt equivalent)
    out_noise = np.sqrt(samp_freq) * fftconvolve(in_noise, b, mode="same")
    return out_noise

def fitness_func(time_vec, data_realiz, psd_vec, samp_freq, param_bounds, input_params):
    ''' A wrapper for glrtqcsig which receives standardized coordinates and 
    sends un-standardized coordinates to glrtqcsig. Serves as the fitness 
    function reference for PSO.
    PARAMETERS:
        time_vec (ndarray): The array of time samples.
        data_realiz (ndarray): The array of data values.
        psd_vec (ndarray): The array of PSD values for positive DFT frequencies.
        samp_freq (float): The sampling frequency in Hertz.
        param_bounds (ndarray): Array of boundary conditions for input_params.
        input_params (iterable): [a1, a2, a3] coefficients for phase po
    RETURNS:
        (float): The fitness function value for given input_params.
    '''
    # First, un-standardize the coordinates
    for i in range(0, len(input_params)):
        bc = param_bounds[i]
        input_params[i] = input_params[i]*(bc[1]-bc[0]) + bc[0]    
    # Compute fitness with GLRT
    return -glrtqcsig(time_vec, data_realiz, psd_vec, input_params, samp_freq)

def main():
    '''Program to determine if a imported data series contains a quadratic 
    chirp signal using PSO and GLRT and to estimate the parameters.'''
    
    # Load the data from the .mat files
    samp_freq_data, samp_freq_train, data_vec, train_vec = load_mats()
    n_samples_data = len(data_vec)
    n_samples_train = len(train_vec)
    # Create time vector for the data
    time_vec = np.arange(n_samples_data) / samp_freq_data
    
    # Estimate the noise psd from the training data
    freq_vec_train, psd_vec = welch(train_vec, samp_freq_train, nperseg=512)
    # Need to resample the psd with interpolation
    k_nyq = (n_samples_data // 2) + 1
    data_len = n_samples_data / samp_freq_data
    new_freqs = np.arange(k_nyq) / data_len
    f = interp1d(freq_vec_train, psd_vec, kind='cubic', fill_value='extrapolate') 
    new_psd = f(new_freqs)
    # clip the psd to handle the seismic wall
    new_psd[new_freqs <= 50] = np.interp(50, new_freqs, new_psd) 
    # plot the psd
    plot_PSD(freq_vec_train, psd_vec, new_freqs, new_psd, 'PSD')
    plot_PSD(freq_vec_train, psd_vec, new_freqs, new_psd, 'PSD', uselog=True)
    gen_spectro(data_vec, 1.0/samp_freq_data, 'Data Spectrogram')
    
    # Fitness function parameter ranges and funtion handle
    a1_min, a1_max = 40.0, 100.0
    a2_min, a2_max = 1.0, 50.0
    a3_min, a3_max = 1.0, 15.0
    param_bounds = np.array([[a1_min, a1_max], [a2_min, a2_max], [a3_min, a3_max]])
    fitness_handle = partial( fitness_func, 
                time_vec, data_vec, new_psd, samp_freq_data, param_bounds)
    # Run lbest PSO
    N_runs = 8
    N_iter = 2000
    N_x = len(param_bounds)
    all_fs, all_best_loc = run_lbestPSO(N_runs, N_iter, N_x, fitness_handle, seed=True)
    # Unstandardize the coordinates
    coords_standardized = all_best_loc[np.argmin(all_fs)]
    coords = np.zeros((N_x))
    for i, val in enumerate(coords_standardized):
        bc = param_bounds[i]
        coords[i] = val*(bc[1]-bc[0]) + bc[0]   
        
    # Now present the results
    print('\n**************************************')
    print('**************************************')
    print('**************************************')
    # Get GLRT value and significance
    GLRT_val = glrtqcsig(time_vec, data_vec, new_psd, coords, samp_freq_data)
    print('\nGLRT value:', GLRT_val)    
    # Generate M data realizations under H0 (data only noise)
    M = 20000
    GLRT_H0 = np.zeros(M)
    np.random.seed(0)
    print(f'\nCalculating the p-value by summing the GLRTs for {M} ', end='')
    print('realizations of noise under the null hypothesis which exceed',end='')
    print(f' the calculated GLRT value above and dividing by {M} ...')
    for m in range(M):
        noise = statgaussnoisegen(n_samples_data, new_freqs, new_psd, 500, samp_freq_data)
        GLRT_H0[m] = glrtqcsig(time_vec, noise, new_psd, coords, samp_freq_data)
    # Compute the p-value
    p = np.sum(GLRT_H0 > GLRT_val) / M
    print("\np-value:", p)
    if p < 0.05:
        print(f'\nSince {p} < 0.05 we conclude that there is a quadratic chirp detection.')
    else:
        print(f'\nSince {p} > 0.05 we conclude that there is not a quadratic chirp detection.')
    print('\nFinal parameters converted back from standardized coordinates:', coords)
    
if __name__ == "__main__":
    main()
