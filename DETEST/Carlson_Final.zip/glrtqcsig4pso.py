# -*- coding: utf-8 -*-
"""
Created on Fri Nov 14 14:06:13 2025

@author: Ben Carlson

Function to calculates the GLRT for a quadratic chirp signal with unknown 
amplitude.
"""
import numpy as np
from math import pi

def crcbgenqcsig(t_vec, snr, coefs):
    ''' Generate a quadratic chirp signal for a given sampling interval.
    PARAMETERS
        t_vec (ndarray): The array of time values.
        snr (float): Scaling factor for signal amplitude.
        coefs (iterable): [a1, a2, a3] coefficients for phase polynomial.
    RETURNS
        f_t (ndarray): The array of chirp signal values.
    '''
    # Generate the signal and normalize
    t_vec_sq = t_vec * t_vec
    φ_t = coefs[0]*t_vec + coefs[1]*(t_vec_sq) + coefs[2]*(t_vec*t_vec_sq)
    f_t = np.sin(2.0*pi*φ_t)
    f_t *= snr / np.linalg.norm(f_t)
    return f_t

def innerprodpsd(x, y, samp_freq, psd_vals_pos):
    '''Calculates the inner product of vectors X and Y for the case of Gaussian
    stationary noise having a specified power spectral density.
    PARAMETERS
        x, y (ndarray): The arrays of signal/data/noise values.
        samp_freq (float): The sampling frequency of X and Y is Fs.
        psd_vals_pos (ndarray): The array of PSD values at positive frequencies 
                                    in the DFT of X and Y.
    RETURNS
        (ndarray): The real component of the inner product of x and y.
    '''
    n = len(x)
    if len(y) != n:
        raise ValueError("Vectors must be the same length.")
    k_nyq = n // 2 + 1
    if len(psd_vals_pos) != k_nyq:
        raise ValueError("PSD values must be specified at positive DFT frequencies.")
    fftx = np.fft.fft(x)
    ffty = np.fft.fft(y)
    # We take care of even or odd number of samples when replicating PSD values
        # for negative frequencies.
    neg_start = 1 - (n % 2)
    psd_full = np.concatenate([psd_vals_pos, psd_vals_pos[(k_nyq - neg_start):1:-1]])
    data_len = samp_freq * n
    inn_prod = np.dot(fftx / psd_full, np.conjugate(ffty)) / data_len
    return np.real(inn_prod)

def normsig4psd(sigVec, sampFreq, psdVec, snr):
    '''Normalize a given signal to have a specified SNR in specified noise PSD.
    PARAMETERS
        sigVec (ndarray): The signal vector to be normalized.
        sampFreq (float): The sampling frequency fs
        psdVec (ndarray): The array of PSD values for positive DFT frequencies.
        snr (float): The target SNR for the signal.
    RETURNS
        normSigVec (ndarray): The normalized signal array.
    '''
    nSamples = len(sigVec)
    kNyq = (nSamples // 2) + 1
    if len(psdVec) != kNyq:
        raise ValueError('Length of PSD is not correct')
    # Norm of signal squared is inner product of signal with itself
    normSigSqrd = innerprodpsd(sigVec, sigVec, sampFreq, psdVec)
    # Normalization factor
    normFac = snr / np.sqrt(normSigSqrd)
    # Normalize signal to specified SNR
    normSigVec = normFac * sigVec
    return normSigVec

def glrtqcsig(x, y, psd_vec, input_params, samp_freq):
    '''Calculates the GLRT for a quadratic chirp signal with unknown amplitude.
    PARAMETERS
        x (ndarray): The array of time samples.
        y (ndarray): The array of data values.
        psd_vec (ndarray): The array of PSD values for positive DFT frequencies.
        input_params (iterable): [a1, a2, a3] coefficients for phase polynomial.
        samp_freq (float): The sampling frequency in Hertz.
    RETURNS
        llr*llr (float): The GLRT for amlitude-estimate case.
    '''
    # Generate the unit norm template signal
    sigVec = crcbgenqcsig(x, 1, input_params)
    templateVec = normsig4psd(sigVec, samp_freq, psd_vec, 1)
    # Inner product with data
    llr = innerprodpsd(y, templateVec, samp_freq, psd_vec)
    # GLRT for unknown amplitude (amplitude-estimated case)
    return llr*llr
